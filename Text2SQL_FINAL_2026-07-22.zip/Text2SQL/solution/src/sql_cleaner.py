from __future__ import annotations

import re


def clean_sql(text: str) -> str:
    text = text.strip()
    fenced = re.search(r"```(?:sql)?\s*(.*?)```", text, re.I | re.S)
    if fenced:
        text = fenced.group(1).strip()
    text = re.sub(r"^\s*(?:SQL\s*:\s*)", "", text, flags=re.I)
    # Keep the first complete SELECT/WITH statement; validation still rejects multiple statements.
    start = re.search(r"\b(?:SELECT|WITH)\b", text, re.I)
    if start:
        text = text[start.start():]
    return text.strip()

