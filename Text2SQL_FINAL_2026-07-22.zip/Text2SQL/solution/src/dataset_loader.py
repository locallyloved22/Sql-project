from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Example:
    domain: str
    id: int
    question: str
    gold_sql: str | None = None


class DatasetLoader:
    """Загружает только явно указанный split; private никогда не выбирается автоматически."""

    def __init__(self, repository_root: str | Path):
        self.root = Path(repository_root).resolve()

    def domains(self, split: str = "public") -> list[str]:
        if split not in {"public", "databases"}:
            raise ValueError("Допустимы только public и databases; private запрещён в baseline")
        base = self.root / ("public/databases" if split == "public" else "databases")
        return sorted(p.name for p in base.iterdir() if p.is_dir() and (p / "schema.sql").exists())

    def load(self, split: str = "public", domain: str | None = None) -> list[Example]:
        if split not in {"public", "databases"}:
            raise ValueError("Private split нельзя использовать для baseline")
        base = self.root / ("public/databases" if split == "public" else "databases")
        paths = [base / domain / "questions.json"] if domain else sorted(base.glob("*/questions.json"))
        result: list[Example] = []
        for path in paths:
            if not path.exists():
                raise FileNotFoundError(path)
            for row in json.loads(path.read_text(encoding="utf-8")):
                result.append(Example(path.parent.name, int(row["id"]), str(row["question"]), row.get("gold_sql")))
        return result

    def load_test_questions(self, split: str = "private", domain: str | None = None) -> list[Example]:
        """Загружает только domain/id/question; gold_sql намеренно не переносится в Example."""
        if split not in {"public", "private"}:
            raise ValueError("split должен быть public или private")
        base = self.root / split / "databases"
        paths = [base / domain / "questions.json"] if domain else sorted(base.glob("*/questions.json"))
        result = []
        for path in paths:
            if not path.exists():
                raise FileNotFoundError(path)
            raw = json.loads(path.read_text(encoding="utf-8"))
            result.extend(Example(path.parent.name, int(row["id"]), str(row["question"]), None) for row in raw)
        return result

    def schema_path(self, domain: str, split: str = "public") -> Path:
        if split not in {"public", "databases"}:
            raise ValueError("Private split нельзя использовать")
        path = self.root / ("public/databases" if split == "public" else "databases") / domain / "schema.sql"
        if not path.exists():
            raise FileNotFoundError(path)
        return path


def write_submission(examples: Iterable[Example], predictions: dict[tuple[str, int], str], path: str | Path) -> None:
    rows = list(examples)
    keys = [(x.domain, x.id) for x in rows]
    if len(keys) != len(set(keys)):
        raise ValueError("Повторяющиеся (domain, id) во входных примерах")
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["domain", "id", "predicted_sql"])
        writer.writeheader()
        for example in rows:
            writer.writerow({"domain": example.domain, "id": example.id, "predicted_sql": predictions.get((example.domain, example.id), "")})
