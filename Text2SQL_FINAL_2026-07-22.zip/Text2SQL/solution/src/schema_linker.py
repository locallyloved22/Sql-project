from __future__ import annotations

import re
from collections import defaultdict

from .schema_parser import Schema


RU_HINTS = {
    "заказ": ("sales_orders", "purchase_orders", "order"), "товар": ("products", "product"),
    "клиент": ("customers", "clients", "customer", "client"), "платеж": ("payments", "payment"),
    "юрист": ("lawyers", "lawyer"), "дел": ("cases", "case"), "суд": ("courts", "hearings"),
    "отправ": ("shipments", "shipment"), "маршрут": ("routes", "route"), "водител": ("drivers", "driver"),
    "рудник": ("mines", "mine"), "минерал": ("mineral_types", "mineral"), "добыч": ("extraction_records", "production_records", "field_production"),
    "скважин": ("wells", "well"), "месторожд": ("fields", "field"), "инцидент": ("incidents", "safety_incidents"),
    "сотрудник": ("employees", "employee"), "контракт": ("contracts", "sales_contracts", "customer_contracts"),
}


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-zа-яё0-9_]+", text.lower()))


def select_relevant_tables(question: str, schema: Schema, max_tables: int = 8) -> list[str]:
    q_tokens = _tokens(question)
    scores: dict[str, float] = defaultdict(float)
    for table in schema.tables.values():
        name_parts = set(table.name.split("_"))
        scores[table.name] += 3 * len(q_tokens & name_parts)
        for column in table.columns:
            scores[table.name] += len(q_tokens & set(column.split("_")))
    q_lower = question.lower()
    for stem, hints in RU_HINTS.items():
        if stem in q_lower:
            for table in schema.tables:
                if table in hints or any(hint in table for hint in hints):
                    scores[table] += 6
    ranked = [name for name, score in sorted(scores.items(), key=lambda x: (-x[1], x[0])) if score > 0]
    if not ranked:
        ranked = list(schema.tables)[: min(3, max_tables)]
    selected = ranked[:max_tables]

    # Add one-hop FK bridge tables while respecting the context limit.
    for table_name in list(selected):
        table = schema.tables[table_name]
        for _, target, _ in table.foreign_keys:
            if target not in selected and len(selected) < max_tables:
                selected.append(target)
        for other in schema.tables.values():
            if any(target == table_name for _, target, _ in other.foreign_keys) and other.name not in selected and len(selected) < max_tables:
                selected.append(other.name)
    return selected

