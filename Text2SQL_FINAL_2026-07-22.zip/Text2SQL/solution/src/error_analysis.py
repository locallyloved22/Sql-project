from __future__ import annotations

import csv
import re
from collections import Counter
from pathlib import Path


ERROR_TYPES = ["wrong_table", "wrong_column", "missing_join", "wrong_join", "wrong_aggregation", "wrong_filter", "wrong_date_filter", "wrong_grouping", "wrong_ordering", "invalid_sql", "hallucinated_schema", "semantically_correct_but_exact_match_failed", "execution_error", "unknown"]


def _count(sql: str, pattern: str) -> int:
    return len(re.findall(pattern, sql, re.I))


def classify_error(predicted: str, gold: str, valid: bool, execution_correct: bool | None, error_message: str = "") -> str:
    if not valid:
        if "неизвестн" in error_message.lower():
            return "hallucinated_schema"
        return "invalid_sql"
    if execution_correct is True and predicted.strip().lower() != gold.strip().lower():
        return "semantically_correct_but_exact_match_failed"
    if error_message:
        return "execution_error"
    p, g = predicted.upper(), gold.upper()
    p_tables = set(re.findall(r"\b(?:FROM|JOIN)\s+(\w+)", p)); g_tables = set(re.findall(r"\b(?:FROM|JOIN)\s+(\w+)", g))
    if p_tables != g_tables:
        return "wrong_table"
    if _count(p, r"\bJOIN\b") < _count(g, r"\bJOIN\b"):
        return "missing_join"
    if _count(p, r"\bJOIN\b") != _count(g, r"\bJOIN\b"):
        return "wrong_join"
    if any(_count(p, rf"\b{x}\s*\(") != _count(g, rf"\b{x}\s*\(") for x in ("COUNT", "SUM", "AVG", "MIN", "MAX")):
        return "wrong_aggregation"
    if _count(p, r"\b(?:EXTRACT|DATE_TRUNC|CURRENT_DATE|INTERVAL)\b") != _count(g, r"\b(?:EXTRACT|DATE_TRUNC|CURRENT_DATE|INTERVAL)\b"):
        return "wrong_date_filter"
    if (" WHERE " in f" {p} ") != (" WHERE " in f" {g} "):
        return "wrong_filter"
    if ("GROUP BY" in p) != ("GROUP BY" in g):
        return "wrong_grouping"
    if ("ORDER BY" in p) != ("ORDER BY" in g):
        return "wrong_ordering"
    return "unknown"


def write_error_report(results_csv: str | Path, output_md: str | Path) -> Counter:
    counts: Counter[str] = Counter()
    with Path(results_csv).open(encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row.get("exact_match") == "True":
                continue
            kind = row.get("error_type") or "unknown"
            counts[kind] += 1
    lines = ["# Error analysis", "", "| Тип ошибки | Количество |", "|---|---:|"]
    for kind, count in counts.most_common():
        lines.append(f"| `{kind}` | {count} |")
    if not counts:
        lines += ["", "Ошибок в переданном файле не найдено."]
    Path(output_md).write_text("\n".join(lines) + "\n", encoding="utf-8")
    return counts
