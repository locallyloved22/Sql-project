from __future__ import annotations

import re
from dataclasses import dataclass, field

from .schema_parser import Schema


FORBIDDEN = {"insert", "update", "delete", "drop", "alter", "truncate", "create", "grant", "revoke", "copy", "call", "do", "merge", "vacuum", "analyze"}


@dataclass
class ValidationResult:
    valid: bool
    errors: list[str] = field(default_factory=list)
    tables: set[str] = field(default_factory=set)
    columns: set[str] = field(default_factory=set)


def _fallback_validate(sql: str, schema: Schema) -> ValidationResult:
    """Conservative fallback used only to give a clear result before sqlglot is installed."""
    errors = ["sqlglot не установлен; используется ограниченная fallback-проверка"]
    stripped = re.sub(r"--.*?$|/\*.*?\*/", " ", sql, flags=re.M | re.S).strip()
    statements = [x for x in stripped.split(";") if x.strip()]
    if len(statements) != 1:
        errors.append("разрешён ровно один SQL-запрос")
    if not re.match(r"^(SELECT\b|WITH\b[\s\S]*\bSELECT\b)", stripped, re.I):
        errors.append("разрешён только SELECT или WITH ... SELECT")
    found_forbidden = sorted(word for word in FORBIDDEN if re.search(rf"\b{word}\b", stripped, re.I))
    if found_forbidden:
        errors.append("запрещённые команды: " + ", ".join(found_forbidden))
    table_source = re.sub(r"\bEXTRACT\s*\([^)]*\)", " ", stripped, flags=re.I)
    tables = {x.lower() for x in re.findall(r"\b(?:FROM|JOIN)\s+\"?([A-Za-z_][\w]*)", table_source, re.I)}
    unknown = tables - set(schema.tables)
    if unknown:
        errors.append("неизвестные таблицы: " + ", ".join(sorted(unknown)))
    blocking = [e for e in errors if not e.startswith("sqlglot не установлен")]
    return ValidationResult(not blocking, errors, tables, set())


def validate_sql(sql: str, schema: Schema) -> ValidationResult:
    try:
        import sqlglot
        from sqlglot import exp
    except ImportError:
        return _fallback_validate(sql, schema)
    errors: list[str] = []
    try:
        expressions = sqlglot.parse(sql, read="postgres")
    except Exception as exc:
        return ValidationResult(False, [f"invalid_sql: {exc}"])
    if len(expressions) != 1:
        return ValidationResult(False, ["разрешён ровно один SQL-запрос"])
    tree = expressions[0]
    if not isinstance(tree, (exp.Select, exp.Union, exp.Intersect, exp.Except)) and not tree.find(exp.Select):
        errors.append("разрешён только SELECT или WITH ... SELECT")
    dangerous_types = tuple(t for name in ("Insert", "Update", "Delete", "Drop", "Alter", "Create", "Command", "Merge") if (t := getattr(exp, name, None)))
    if dangerous_types and any(tree.find(kind) for kind in dangerous_types):
        errors.append("обнаружена запрещённая SQL-команда")
    cte_names = {cte.alias_or_name.lower() for cte in tree.find_all(exp.CTE)}
    tables = {table.name.lower() for table in tree.find_all(exp.Table) if table.name.lower() not in cte_names}
    unknown_tables = tables - set(schema.tables)
    if unknown_tables:
        errors.append("неизвестные таблицы: " + ", ".join(sorted(unknown_tables)))
    aliases = {table.alias_or_name.lower(): table.name.lower() for table in tree.find_all(exp.Table)}
    columns: set[str] = set()
    for column in tree.find_all(exp.Column):
        name = column.name.lower()
        if name == "*":
            continue
        columns.add(name)
        qualifier = column.table.lower() if column.table else ""
        if qualifier and qualifier in aliases and aliases[qualifier] in schema.tables:
            if name not in schema.tables[aliases[qualifier]].columns:
                errors.append(f"неизвестная колонка: {qualifier}.{name}")
        elif not qualifier and name not in schema.column_names:
            # SELECT aliases are allowed in ORDER BY/GROUP BY.
            select_aliases = {item.alias.lower() for item in tree.find_all(exp.Alias) if item.alias}
            if name not in select_aliases:
                errors.append(f"неизвестная колонка: {name}")
    return ValidationResult(not errors, sorted(set(errors)), tables, columns)
