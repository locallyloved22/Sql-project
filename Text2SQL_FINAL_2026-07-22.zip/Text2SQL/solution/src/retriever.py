from __future__ import annotations

import math
import re
from collections import Counter

from .dataset_loader import Example


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-zа-яё0-9_]+", text.lower())


class Retriever:
    def __init__(self, examples: list[Example]):
        self.examples = examples
        docs = [set(tokenize(x.question)) for x in examples]
        df = Counter(token for doc in docs for token in doc)
        self.idf = {token: math.log((len(docs) + 1) / (count + 1)) + 1 for token, count in df.items()}

    def _vector(self, text: str) -> Counter[str]:
        counts = Counter(tokenize(text))
        return Counter({t: n * self.idf.get(t, 1.0) for t, n in counts.items()})

    def search(self, question: str, domain: str, k: int = 4, exclude_id: int | None = None) -> list[Example]:
        query = self._vector(question)
        qnorm = math.sqrt(sum(v * v for v in query.values())) or 1.0
        scored = []
        for example in self.examples:
            if example.domain != domain or (exclude_id is not None and example.id == exclude_id):
                continue
            doc = self._vector(example.question)
            dnorm = math.sqrt(sum(v * v for v in doc.values())) or 1.0
            score = sum(value * doc.get(token, 0.0) for token, value in query.items()) / (qnorm * dnorm)
            scored.append((score, example))
        return [example for _, example in sorted(scored, key=lambda x: (-x[0], x[1].id))[:k]]

