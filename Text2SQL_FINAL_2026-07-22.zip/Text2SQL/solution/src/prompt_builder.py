from __future__ import annotations

from .dataset_loader import Example


SYSTEM_PROMPT = """Ты — генератор безопасных SQL-запросов.
Правила:
1. Используй диалект PostgreSQL.
2. Используй только таблицы и колонки из предоставленной схемы; не придумывай поля.
3. Учитывай первичные и внешние ключи при JOIN.
4. Верни ровно один SQL-запрос и ничего больше.
5. Не используй Markdown и не добавляй объяснений.
6. Разрешён только SELECT или WITH ... SELECT.
7. Запрещены INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, CREATE, GRANT, REVOKE, COPY и CALL.
8. По возможности следуй стилю приведённых публичных примеров.
"""


def build_messages(question: str, schema_ddl: str, examples: list[Example] | None = None, error: str | None = None, previous_sql: str | None = None) -> list[dict[str, str]]:
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    for example in examples or []:
        if example.gold_sql:
            messages.append({"role": "user", "content": f"Схема та же. Вопрос: {example.question}"})
            messages.append({"role": "assistant", "content": example.gold_sql})
    content = f"Схема PostgreSQL:\n{schema_ddl}\n\nВопрос: {question}"
    if error:
        content += f"\n\nПредыдущий SQL:\n{previous_sql or ''}\n\nОшибка проверки/выполнения:\n{error}\nИсправь запрос."
    messages.append({"role": "user", "content": content})
    return messages
