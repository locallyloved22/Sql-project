from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Column:
    name: str
    data_type: str


@dataclass
class Table:
    name: str
    columns: dict[str, Column] = field(default_factory=dict)
    foreign_keys: list[tuple[str, str, str]] = field(default_factory=list)
    ddl: str = ""


@dataclass
class Schema:
    tables: dict[str, Table]
    raw_ddl: str

    @property
    def column_names(self) -> set[str]:
        return {name for table in self.tables.values() for name in table.columns}


def _split_definitions(body: str) -> list[str]:
    parts, current, depth = [], [], 0
    for char in body:
        depth += char == "("
        depth -= char == ")"
        if char == "," and depth == 0:
            parts.append("".join(current).strip())
            current = []
        else:
            current.append(char)
    if current:
        parts.append("".join(current).strip())
    return parts


def parse_schema_text(ddl: str) -> Schema:
    tables: dict[str, Table] = {}
    pattern = re.compile(r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?P<name>[\w\"]+)\s*\((?P<body>.*?)\)\s*;", re.I | re.S)
    for match in pattern.finditer(ddl):
        name = match.group("name").strip('"').lower()
        table = Table(name=name, ddl=match.group(0))
        for definition in _split_definitions(match.group("body")):
            col_match = re.match(r'\s*"?([A-Za-z_][\w]*)"?\s+([A-Za-z]+(?:\s+PRECISION)?(?:\s*\([^)]*\))?)', definition)
            if col_match and col_match.group(1).upper() not in {"PRIMARY", "FOREIGN", "UNIQUE", "CHECK", "CONSTRAINT"}:
                col_name = col_match.group(1).lower()
                table.columns[col_name] = Column(col_name, col_match.group(2).upper())
                inline = re.search(r"REFERENCES\s+\"?([\w]+)\"?\s*\(\s*\"?([\w]+)\"?\s*\)", definition, re.I)
                if inline:
                    table.foreign_keys.append((col_name, inline.group(1).lower(), inline.group(2).lower()))
            fk = re.search(r"FOREIGN\s+KEY\s*\(\s*\"?([\w]+)\"?\s*\)\s*REFERENCES\s+\"?([\w]+)\"?\s*\(\s*\"?([\w]+)\"?\s*\)", definition, re.I)
            if fk:
                table.foreign_keys.append(tuple(x.lower() for x in fk.groups()))
        tables[name] = table
    if not tables:
        raise ValueError("В DDL не найдено ни одной CREATE TABLE")
    return Schema(tables, ddl)


def parse_schema(path: str | Path) -> Schema:
    return parse_schema_text(Path(path).read_text(encoding="utf-8"))


def render_schema(schema: Schema, table_names: list[str] | None = None) -> str:
    names = table_names or list(schema.tables)
    return "\n\n".join(schema.tables[name].ddl for name in names if name in schema.tables)

