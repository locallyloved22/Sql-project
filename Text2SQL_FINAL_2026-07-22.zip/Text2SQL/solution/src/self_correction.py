from __future__ import annotations

from .dataset_loader import Example
from .llm_client import LLMClient
from .prompt_builder import build_messages
from .sql_cleaner import clean_sql


def correct_sql(client: LLMClient, question: str, schema_ddl: str, previous_sql: str, error: str, examples: list[Example]) -> str:
    messages = build_messages(question, schema_ddl, examples, error=error, previous_sql=previous_sql)
    return clean_sql(client.generate(messages, candidates=examples))

