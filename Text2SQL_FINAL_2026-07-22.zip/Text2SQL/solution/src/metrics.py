from __future__ import annotations

import math
import re
import statistics
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Iterable


def normalize_sql(sql: str) -> str:
    text = re.sub(r"--.*?$|/\*.*?\*/", " ", str(sql), flags=re.M | re.S)
    text = text.strip().rstrip(";").lower()
    return " ".join(text.split())


def exact_match(predicted: str, gold: str) -> bool:
    return bool(predicted.strip()) and normalize_sql(predicted) == normalize_sql(gold)


def sql_token_set(sql: str) -> set[str]:
    return set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|<>|!=|<=|>=|[-+*/=<>]", normalize_sql(sql)))


def jaccard_similarity(predicted: str, gold: str) -> float:
    left, right = sql_token_set(predicted), sql_token_set(gold)
    if not left and not right:
        return 1.0
    return len(left & right) / len(left | right) if left | right else 0.0


def _normal(value: Any) -> Any:
    if value is None:
        return ("null",)
    if isinstance(value, bool):
        return ("bool", value)
    if isinstance(value, (int, float, Decimal)):
        number = float(value)
        if math.isnan(number):
            return ("number", "nan")
        return ("number", round(number, 8))
    if isinstance(value, (date, datetime)):
        return ("date", value.isoformat())
    if isinstance(value, bytes):
        return ("bytes", value.hex())
    return ("text", str(value).strip())


def normalize_rows(rows: Iterable[Iterable[Any]]) -> list[tuple[Any, ...]]:
    return [tuple(_normal(value) for value in row) for row in rows]


def compare_results(predicted_rows: list[tuple[Any, ...]], gold_rows: list[tuple[Any, ...]], ordered: bool) -> bool:
    left, right = normalize_rows(predicted_rows), normalize_rows(gold_rows)
    if not ordered:
        left, right = sorted(left, key=repr), sorted(right, key=repr)
    return left == right


def has_order_by(sql: str) -> bool:
    return bool(re.search(r"\bORDER\s+BY\b", sql, re.I))


def latency_summary(values: list[float]) -> dict[str, float | None]:
    return {"mean": statistics.mean(values) if values else None, "median": statistics.median(values) if values else None}

