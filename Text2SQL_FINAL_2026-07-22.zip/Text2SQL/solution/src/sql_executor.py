from __future__ import annotations

import os
import re
from dataclasses import dataclass
from decimal import Decimal
from typing import Any


@dataclass
class ExecutionResult:
    available: bool
    success: bool
    rows: list[tuple[Any, ...]] | None = None
    columns: list[str] | None = None
    error: str | None = None


def dsn_for_domain(domain: str) -> str | None:
    key = "TEXT2SQL_DSN_" + re.sub(r"\W+", "_", domain).upper()
    return os.getenv(key) or os.getenv("TEXT2SQL_DSN") or None


def execute_readonly(
    sql: str,
    dsn: str | None,
    timeout_ms: int = 5000,
    max_rows: int | None = 100,
) -> ExecutionResult:
    """Execute a single read-only query.

    ``max_rows=None`` fetches the complete result and is intended for exact
    benchmark evaluation. Interactive callers keep the safe 100-row default.
    """
    if not dsn:
        return ExecutionResult(False, False, error="PostgreSQL DSN не задан; Execution Accuracy недоступна")
    try:
        import psycopg
    except ImportError:
        return ExecutionResult(False, False, error="psycopg не установлен; Execution Accuracy недоступна")
    try:
        with psycopg.connect(dsn, autocommit=False) as conn:
            with conn.transaction():
                with conn.cursor() as cursor:
                    cursor.execute("SET TRANSACTION READ ONLY")
                    cursor.execute("SELECT set_config('statement_timeout', %s, true)", (str(int(timeout_ms)),))
                    cursor.execute(sql)
                    columns = [item.name for item in cursor.description] if cursor.description else []
                    if not cursor.description:
                        rows = []
                    elif max_rows is None:
                        rows = cursor.fetchall()
                    else:
                        rows = cursor.fetchmany(max_rows)
            conn.rollback()
        return ExecutionResult(True, True, rows=rows, columns=columns)
    except psycopg.OperationalError as exc:
        return ExecutionResult(False, False, error=f"PostgreSQL недоступен: {exc}")
    except Exception as exc:
        return ExecutionResult(True, False, error=str(exc))
