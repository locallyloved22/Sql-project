from __future__ import annotations

import time
from dataclasses import dataclass

from .config import Config
from .dataset_loader import DatasetLoader, Example
from .llm_client import LLMClient, create_client
from .prompt_builder import build_messages
from .retriever import Retriever
from .schema_linker import select_relevant_tables
from .schema_parser import parse_schema, render_schema
from .self_correction import correct_sql
from .sql_cleaner import clean_sql
from .sql_executor import ExecutionResult, dsn_for_domain, execute_readonly
from .sql_validator import ValidationResult, validate_sql


@dataclass
class GenerationResult:
    sql: str
    latency_seconds: float
    validation: ValidationResult
    execution: ExecutionResult | None
    selected_tables: list[str]
    attempts: int
    error: str | None = None
    initial_sql: str | None = None
    corrected_sql: str | None = None
    initial_execution_error: str | None = None


class Text2SQLPipeline:
    def __init__(self, repository_root: str, config: Config, client: LLMClient | None = None):
        self.config = config
        self.loader = DatasetLoader(repository_root)
        self.public_examples = self.loader.load("public")
        self.retriever = Retriever(self.public_examples)
        self.client = client or create_client(config)

    def _examples(self, question: str, domain: str, question_id: int | None) -> list[Example]:
        if self.config.few_shot_mode == "zero":
            return []
        if self.config.few_shot_mode == "static":
            return [x for x in self.public_examples if x.domain == domain and x.id != question_id][: self.config.few_shot_count]
        return self.retriever.search(question, domain, self.config.few_shot_count, exclude_id=question_id)

    def generate(
        self,
        question: str,
        domain: str,
        question_id: int | None = None,
        execute: bool = False,
        execution_max_rows: int | None = 100,
    ) -> GenerationResult:
        schema = parse_schema(self.loader.schema_path(domain))
        selected = select_relevant_tables(question, schema, self.config.max_tables) if self.config.schema_linking else list(schema.tables)
        ddl = render_schema(schema, selected)
        examples = self._examples(question, domain, question_id)
        start = time.perf_counter()
        raw = self.client.generate(build_messages(question, ddl, examples), candidates=examples)
        sql = clean_sql(raw)
        initial_sql = sql
        validation = validate_sql(sql, schema) if self.config.validation else ValidationResult(True)
        execution: ExecutionResult | None = None
        attempts = 1
        error = "; ".join(validation.errors) if not validation.valid else None
        initial_execution_error = None

        if validation.valid and execute:
            execution = execute_readonly(
                sql,
                dsn_for_domain(domain),
                self.config.statement_timeout_ms,
                max_rows=execution_max_rows,
            )
            if execution.available and not execution.success:
                error = execution.error
                initial_execution_error = execution.error

        while self.config.self_correction and error and attempts <= self.config.max_corrections:
            sql = correct_sql(self.client, question, ddl, sql, error, examples)
            attempts += 1
            validation = validate_sql(sql, schema) if self.config.validation else ValidationResult(True)
            error = "; ".join(validation.errors) if not validation.valid else None
            if validation.valid and execute:
                execution = execute_readonly(
                    sql,
                    dsn_for_domain(domain),
                    self.config.statement_timeout_ms,
                    max_rows=execution_max_rows,
                )
                if execution.available and not execution.success:
                    error = execution.error
        return GenerationResult(sql, time.perf_counter() - start, validation, execution, selected, attempts, error, initial_sql, sql if attempts > 1 else None, initial_execution_error)
