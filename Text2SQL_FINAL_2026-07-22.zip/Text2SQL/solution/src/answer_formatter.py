from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any


def json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.hex()
    return str(value)


def safe_rows(rows: list[tuple[Any, ...]] | None) -> list[list[Any]]:
    return [[json_safe(value) for value in row] for row in (rows or [])]


def format_answer(columns: list[str], rows: list[list[Any]]) -> str:
    if not rows:
        return "Запрос выполнен, но подходящих строк не найдено."
    if len(rows) == 1 and len(rows[0]) == 1:
        return f"Результат: {rows[0][0]}."
    shown = rows[:10]
    lines = []
    for index, row in enumerate(shown, 1):
        values = []
        for column, value in zip(columns, row):
            if value is not None:
                values.append(f"{column}: {value}")
        lines.append(f"{index}. " + " — ".join(values))
    suffix = f"\nПоказаны первые {len(shown)} из {len(rows)} строк." if len(rows) > len(shown) else ""
    return "\n".join(lines) + suffix

