from __future__ import annotations

import json
import urllib.error
import urllib.request
from abc import ABC, abstractmethod

from .config import Config
from .dataset_loader import Example


class LLMError(RuntimeError):
    pass


class LLMClient(ABC):
    @abstractmethod
    def generate(self, messages: list[dict[str, str]], candidates: list[Example] | None = None) -> str:
        raise NotImplementedError


def _post_json(url: str, payload: dict, headers: dict[str, str], timeout: float) -> dict:
    request = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json", **headers}, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as exc:
        body = exc.read().decode(errors="replace")[:1000]
        raise LLMError(f"LLM API вернул HTTP {exc.code}: {body}") from exc
    except urllib.error.URLError as exc:
        raise LLMError(f"Не удалось подключиться к LLM API: {exc.reason}") from exc


class OpenAICompatibleClient(LLMClient):
    def __init__(self, config: Config):
        if not config.api_key:
            raise LLMError("Не задан LLM_API_KEY. Заполните переменную окружения или используйте --provider mock/ollama.")
        if not config.model:
            raise LLMError("Не задан LLM_MODEL.")
        self.config = config

    def generate(self, messages: list[dict[str, str]], candidates: list[Example] | None = None) -> str:
        url = self.config.base_url.rstrip("/") + "/chat/completions"
        data = _post_json(url, {"model": self.config.model, "messages": messages, "temperature": self.config.temperature}, {"Authorization": f"Bearer {self.config.api_key}"}, self.config.timeout_seconds)
        try:
            return str(data["choices"][0]["message"]["content"])
        except (KeyError, IndexError, TypeError) as exc:
            raise LLMError(f"Неожиданный формат ответа OpenAI-compatible API: {data}") from exc


class OllamaClient(LLMClient):
    def __init__(self, config: Config):
        self.config = config
        if not config.model:
            raise LLMError("Для Ollama задайте LLM_MODEL или model в config.")

    def generate(self, messages: list[dict[str, str]], candidates: list[Example] | None = None) -> str:
        base = self.config.base_url
        if base == "https://api.openai.com/v1":
            base = "http://localhost:11434"
        data = _post_json(base.rstrip("/") + "/api/chat", {"model": self.config.model, "messages": messages, "stream": False, "options": {"temperature": self.config.temperature}}, {}, self.config.timeout_seconds)
        try:
            return str(data["message"]["content"])
        except (KeyError, TypeError) as exc:
            raise LLMError(f"Неожиданный формат ответа Ollama: {data}") from exc


class MockClient(LLMClient):
    """Только test fixtures. Не изображает настоящую языковую модель."""

    FIXTURES = [
        (("топ-5 покупател", "пять покупател"), "SELECT c.company_name, c.contact_name, SUM(so.total_amount) AS total_amount FROM customers c JOIN sales_orders so ON so.customer_id = c.customer_id GROUP BY c.customer_id, c.company_name, c.contact_name ORDER BY total_amount DESC LIMIT 5;"),
        (("сколько заказов", "заказов было оформлено"), "SELECT COUNT(*) AS order_count FROM sales_orders WHERE EXTRACT(YEAR FROM order_date) = 2023;"),
        (("товары продаются лучше",), "SELECT p.product_name, SUM(soi.quantity) AS sold_quantity FROM products p JOIN sales_order_items soi ON soi.product_id = p.product_id GROUP BY p.product_id, p.product_name ORDER BY sold_quantity DESC LIMIT 10;"),
        (("юристы ведут больше",), "SELECT l.first_name, l.last_name, COUNT(ca.case_id) AS case_count FROM lawyers l JOIN case_assignments ca ON ca.lawyer_id = l.lawyer_id GROUP BY l.lawyer_id, l.first_name, l.last_name ORDER BY case_count DESC LIMIT 10;"),
        (("неоплаченные счета",), "SELECT invoice_number, total_amount, paid_amount, status FROM invoices WHERE status <> 'paid' ORDER BY total_amount DESC LIMIT 100;"),
        (("судебных заседаний",), "SELECT COUNT(*) AS hearing_count FROM hearings WHERE EXTRACT(YEAR FROM hearing_date) = 2023;"),
        (("маршруты используются чаще",), "SELECT r.route_code, COUNT(t.trip_id) AS trip_count FROM routes r JOIN trips t ON t.route_id = r.route_id GROUP BY r.route_id, r.route_code ORDER BY trip_count DESC LIMIT 10;"),
        (("пять водителей", "5 водителей"), "SELECT d.first_name, d.last_name, COUNT(t.trip_id) AS trip_count FROM drivers d JOIN trips t ON t.driver_id = d.driver_id GROUP BY d.driver_id, d.first_name, d.last_name ORDER BY trip_count DESC LIMIT 5;"),
        (("общий вес",), "SELECT SUM(total_weight_kg) AS total_weight_kg FROM shipments;"),
        (("рудники добыли больше",), "SELECT m.mine_name, SUM(er.ore_tonnes) AS ore_tonnes FROM mines m JOIN extraction_records er ON er.mine_id = m.mine_id GROUP BY m.mine_id, m.mine_name ORDER BY ore_tonnes DESC LIMIT 10;"),
        (("оборудование, находящееся на ремонте", "оборудование на ремонте"), "SELECT equipment_code, status, total_operating_hours FROM equipment WHERE status = 'maintenance' ORDER BY equipment_code LIMIT 100;"),
        (("минерал добывается чаще",), "SELECT mt.mineral_name, COUNT(er.record_id) AS extraction_count FROM mineral_types mt JOIN extraction_records er ON er.mineral_type_id = mt.mineral_type_id GROUP BY mt.mineral_type_id, mt.mineral_name ORDER BY extraction_count DESC LIMIT 10;"),
        (("скважины дают наибольшую добычу",), "SELECT w.well_name, SUM(pr.oil_bbl) AS oil_bbl FROM wells w JOIN production_records pr ON pr.well_id = w.well_id GROUP BY w.well_id, w.well_name ORDER BY oil_bbl DESC LIMIT 10;"),
        (("объём добычи по месторождениям", "объем добычи по месторождениям"), "SELECT f.field_name, SUM(fp.oil_bbl) AS oil_bbl FROM fields f JOIN field_production fp ON fp.field_id = f.field_id GROUP BY f.field_id, f.field_name ORDER BY oil_bbl DESC;"),
        (("платформы сейчас активны",), "SELECT platform_name, platform_type, status FROM platforms WHERE status = 'operational' ORDER BY platform_name LIMIT 100;"),
    ]

    def generate(self, messages: list[dict[str, str]], candidates: list[Example] | None = None) -> str:
        content = messages[-1].get("content", "").lower()
        question = content.split("вопрос:")[-1].split("\n\n")[0].strip()
        for needles, sql in self.FIXTURES:
            if any(needle in question for needle in needles):
                return sql
        return "SELECT 1;"


def create_client(config: Config) -> LLMClient:
    if config.provider == "mock":
        return MockClient()
    return {"openai": OpenAICompatibleClient, "ollama": OllamaClient}[config.provider](config)
