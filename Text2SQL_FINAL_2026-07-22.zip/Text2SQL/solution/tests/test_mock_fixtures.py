from pathlib import Path

from src.config import Config
from src.generator import Text2SQLPipeline


ROOT = Path(__file__).resolve().parents[2]


def test_top_five_fixture_uses_limit_five():
    pipeline = Text2SQLPipeline(str(ROOT), Config(provider="mock", model="mock-test-fixtures"))
    result = pipeline.generate("Покажи топ-5 покупателей по общей сумме заказов", "01_trading_company")
    assert result.validation.valid
    assert "LIMIT 5" in result.sql.upper()


def test_unknown_mock_question_is_explicit_fixture_fallback():
    pipeline = Text2SQLPipeline(str(ROOT), Config(provider="mock", model="mock-test-fixtures"))
    assert pipeline.generate("Совершенно неизвестный вопрос", "01_trading_company").sql == "SELECT 1;"

