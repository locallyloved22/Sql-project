from pathlib import Path

from evaluate import _metrics, write_metrics


def _row(**overrides):
    row = {
        "exact_match": False,
        "normalized_exact_match": False,
        "valid_sql": False,
        "execution_correct": False,
        "jaccard_similarity": 0.5,
        "latency_seconds": 1.0,
        "correction_count": 0,
        "domain": "01_trading_company",
        "complexity": "easy",
        "sql_type": "select",
        "error_type": "execution_error",
    }
    row.update(overrides)
    return row


def test_failed_execution_remains_in_execution_accuracy_denominator():
    metrics = _metrics([
        _row(execution_correct=True, valid_sql=True),
        _row(execution_correct=False, valid_sql=False),
    ], 0.0, 2.0)
    assert metrics["execution_accuracy"] == 0.5
    assert metrics["valid_sql_rate"] == 0.5


def test_report_contains_domain_score_and_final_score(tmp_path: Path):
    output = tmp_path / "metrics.json"
    report = write_metrics([
        _row(exact_match=True, normalized_exact_match=True, valid_sql=True, execution_correct=True),
    ], output, latency_min=0.0, latency_max=2.0)
    assert output.exists()
    assert report["by_domain"]["01_trading_company"]["score"] is not None
    assert report["final_score"] == report["by_domain"]["01_trading_company"]["score"]
