from src.config import Config


def test_api_key_can_be_passed_without_environment(monkeypatch):
    monkeypatch.delenv("LLM_API_KEY", raising=False)
    config = Config(provider="openai", model="test", api_key_value="secret-in-memory")
    assert config.api_key == "secret-in-memory"
    assert "secret-in-memory" not in repr(config)
