from src.metrics import compare_results, exact_match, jaccard_similarity


def test_exact_match_normalizes_case_whitespace_and_semicolon():
    assert exact_match(" SELECT  * FROM users ", "select *   from USERS;")


def test_jaccard_bounds_and_identity():
    assert jaccard_similarity("SELECT a FROM t", "SELECT a FROM t") == 1.0
    assert 0 <= jaccard_similarity("SELECT a FROM t", "SELECT b FROM x") <= 1


def test_result_comparison_order_and_float():
    assert compare_results([(1.000000001,), (None,)], [(None,), (1.0,)], ordered=False)
    assert not compare_results([(1,), (2,)], [(2,), (1,)], ordered=True)


def test_result_comparison_does_not_ignore_rows_after_first_hundred():
    predicted = [(number,) for number in range(101)]
    gold = [(number,) for number in range(100)] + [(999,)]
    assert not compare_results(predicted, gold, ordered=True)
