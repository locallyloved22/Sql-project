from decimal import Decimal

from src.answer_formatter import format_answer, safe_rows


def test_json_safe_and_human_answer():
    rows = safe_rows([("Компания A", Decimal("1250000.50"))])
    assert rows == [["Компания A", 1250000.5]]
    answer = format_answer(["company", "total"], rows)
    assert "Компания A" in answer
    assert "1250000.5" in answer
