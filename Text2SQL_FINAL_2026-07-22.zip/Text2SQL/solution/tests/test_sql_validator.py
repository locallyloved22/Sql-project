from src.schema_parser import parse_schema_text
from src.sql_validator import validate_sql


SCHEMA = parse_schema_text("CREATE TABLE users (id SERIAL PRIMARY KEY, name TEXT);")


def test_allows_select():
    assert validate_sql("SELECT id FROM users;", SCHEMA).valid


def test_rejects_dangerous_sql():
    assert not validate_sql("DROP TABLE users;", SCHEMA).valid
    assert not validate_sql("SELECT 1; DELETE FROM users;", SCHEMA).valid


def test_rejects_unknown_table():
    assert not validate_sql("SELECT * FROM hallucination;", SCHEMA).valid

