from pathlib import Path

from src.schema_parser import parse_schema


ROOT = Path(__file__).resolve().parents[2]


def test_parse_schema_and_foreign_key():
    schema = parse_schema(ROOT / "databases/01_trading_company/schema.sql")
    assert len(schema.tables) == 20
    assert "sales_orders" in schema.tables
    assert "customer_id" in schema.tables["sales_orders"].columns
    assert ("customer_id", "customers", "customer_id") in schema.tables["sales_orders"].foreign_keys

