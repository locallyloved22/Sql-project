from pathlib import Path

import pytest

from src.dataset_loader import DatasetLoader, Example, write_submission


ROOT = Path(__file__).resolve().parents[2]


def test_public_dataset_has_250_examples():
    rows = DatasetLoader(ROOT).load("public")
    assert len(rows) == 250
    assert len({(x.domain, x.id) for x in rows}) == 250


def test_private_is_rejected():
    with pytest.raises(ValueError):
        DatasetLoader(ROOT).load("private")


def test_submission_shape(tmp_path):
    rows = [Example("domain", 1, "q")]
    path = tmp_path / "submission.csv"
    write_submission(rows, {("domain", 1): "SELECT 1;"}, path)
    assert path.read_text().splitlines() == ["domain,id,predicted_sql", "domain,1,SELECT 1;"]

