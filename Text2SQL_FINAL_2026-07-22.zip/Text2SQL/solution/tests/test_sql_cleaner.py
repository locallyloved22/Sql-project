from src.sql_cleaner import clean_sql


def test_removes_markdown_and_explanation():
    assert clean_sql("Ответ:\n```sql\nSELECT 1;\n```") == "SELECT 1;"

