#!/usr/bin/env python3
"""Friendly browser UI for the Text2SQL pipeline."""
from __future__ import annotations

import csv
import io
import os
import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app import DOMAINS, ROOT, run_question
from src.config import Config, load_dotenv
from src.generator import Text2SQLPipeline
from src.llm_client import LLMError
from src.sql_executor import dsn_for_domain, execute_readonly


DOMAIN_LABELS = {
    "01_trading_company": "Торговая компания",
    "02_legal_firm": "Юридическая фирма",
    "03_logistics_company": "Логистическая компания",
    "04_mining_company": "Горнодобывающая компания",
    "05_oil_company": "Нефтяная компания",
}

EXAMPLES = {
    "01_trading_company": [
        "Покажи топ-5 покупателей по общей сумме заказов",
        "Сколько заказов было оформлено в 2023 году?",
        "Какие товары продаются лучше всего?",
    ],
    "02_legal_firm": [
        "Какие юристы ведут больше всего дел?",
        "Покажи самые крупные неоплаченные счета",
        "Сколько судебных заседаний было в 2023 году?",
    ],
    "03_logistics_company": [
        "Какие маршруты используются чаще всего?",
        "Покажи пять водителей с наибольшим числом рейсов",
        "Какой общий вес всех отправлений?",
    ],
    "04_mining_company": [
        "Какие рудники добыли больше всего руды?",
        "Покажи оборудование, находящееся на ремонте",
        "Какой минерал добывается чаще всего?",
    ],
    "05_oil_company": [
        "Какие скважины дают наибольшую добычу?",
        "Покажи объём добычи по месторождениям",
        "Какие платформы сейчас активны?",
    ],
}

PROVIDER_NAMES = {
    "openai": "OpenAI / совместимый API",
    "ollama": "Ollama — локальная открытая модель",
    "mock": "Демо — только готовые примеры",
}


def _initial_provider() -> str:
    load_dotenv()
    configured = os.getenv("LLM_PROVIDER", "").lower()
    if configured in PROVIDER_NAMES:
        return configured
    return "openai" if os.getenv("LLM_API_KEY") else "mock"


def _config(provider: str, model: str, base_url: str, api_key: str) -> Config:
    return Config.from_file(
        None,
        provider=provider,
        model=model.strip(),
        base_url=base_url.strip(),
        api_key_value=api_key.strip() or None,
    )


@st.cache_data(ttl=5, show_spinner=False)
def _db_available(domain: str) -> tuple[bool, str]:
    result = execute_readonly("SELECT 1", dsn_for_domain(domain), timeout_ms=1500, max_rows=1)
    if result.success:
        return True, "База данных готова"
    return False, result.error or "База данных недоступна"


def _rows_csv(columns: list[str], rows: list[list[object]]) -> bytes:
    stream = io.StringIO()
    writer = csv.writer(stream)
    writer.writerow(columns)
    writer.writerows(rows)
    return stream.getvalue().encode("utf-8-sig")


def _render_result(data: dict) -> None:
    if data["final_status"] == "success":
        st.success("Запрос выполнен")
        st.markdown("### Ответ")
        st.write(data["answer"])
        if data["columns"]:
            st.markdown("### Данные")
            records = [dict(zip(data["columns"], row)) for row in data["rows"]]
            st.dataframe(records, width="stretch", hide_index=True)
            st.download_button(
                "Скачать результат в CSV",
                _rows_csv(data["columns"], data["rows"]),
                file_name="text2sql_result.csv",
                mime="text/csv",
            )
    else:
        st.error("Не удалось получить результат")
        st.write(data.get("error") or "Проверьте настройки модели и состояние баз данных.")

    with st.expander("Показать SQL и технические детали"):
        st.code(data["generated_sql"] or "SQL не сгенерирован", language="sql")
        col1, col2, col3 = st.columns(3)
        col1.metric("Строк", data["row_count"])
        col2.metric("Время", f"{data['latency_seconds']:.2f} с")
        col3.metric("Исправлений", data["correction_attempts"])
        st.caption(
            f"Модель: {data['model']} · Провайдер: {data['provider']} · "
            f"Статус: {data['execution_status']}"
        )
        if data.get("validation_errors"):
            st.warning("; ".join(data["validation_errors"]))


st.set_page_config(
    page_title="Text2SQL — вопрос к данным",
    page_icon="🔎",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
      .block-container {max-width: 1120px; padding-top: 2rem;}
      [data-testid="stSidebar"] {min-width: 320px;}
      .hero {padding: 1.35rem 1.5rem; border-radius: 18px;
             background: linear-gradient(135deg, #132238, #254d70); color: white;
             margin-bottom: 1.2rem;}
      .hero h1 {margin: 0 0 .35rem 0; font-size: 2rem;}
      .hero p {margin: 0; opacity: .9;}
    </style>
    <div class="hero">
      <h1>Text2SQL</h1>
      <p>Задайте вопрос обычными словами — приложение найдёт ответ в базе данных.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

if "history" not in st.session_state:
    st.session_state.history = []
if "question" not in st.session_state:
    st.session_state.question = ""

with st.sidebar:
    st.header("Настройки")
    initial_provider = _initial_provider()
    provider = st.selectbox(
        "Модель",
        list(PROVIDER_NAMES),
        index=list(PROVIDER_NAMES).index(initial_provider),
        format_func=PROVIDER_NAMES.get,
        help="Для любых вопросов используйте OpenAI или Ollama. Демо знает только готовые примеры.",
    )

    env_model = os.getenv("LLM_MODEL", "")
    env_url = os.getenv("LLM_BASE_URL", "")
    if provider == "openai":
        model = st.text_input("Название модели", value=env_model or "gpt-5.6-sol")
        base_url = st.text_input("Адрес API", value=env_url or "https://api.openai.com/v1")
        api_key = st.text_input(
            "API-ключ",
            value="",
            type="password",
            placeholder="Вставьте ключ сюда",
            help="Ключ используется только в текущем процессе и не сохраняется интерфейсом на диск.",
        )
        if not api_key and not os.getenv("LLM_API_KEY"):
            st.info("Чтобы задавать любые вопросы, вставьте API-ключ.")
    elif provider == "ollama":
        model = st.text_input("Локальная модель", value=env_model or "qwen2.5-coder:7b")
        base_url = st.text_input("Адрес Ollama", value=env_url or "http://localhost:11434")
        api_key = ""
        st.caption("Ollama должна быть установлена и запущена. Это режим для открытой модели.")
    else:
        model, base_url, api_key = "mock-test-fixtures", "", ""
        st.warning("Демо-режим работает только с примерами из списка и не является настоящей LLM.")

    st.divider()
    st.caption("SQL выполняется только в read-only режиме. Изменение и удаление данных запрещены.")

domain = st.selectbox(
    "С какой базой работаем?",
    DOMAINS,
    format_func=lambda value: DOMAIN_LABELS.get(value, value),
)

db_ok, db_message = _db_available(domain)
if db_ok:
    st.caption("🟢 " + db_message)
else:
    st.error("База данных не запущена. Откройте Docker Desktop и заново запустите START_TEXT2SQL.command.")
    with st.expander("Техническая ошибка"):
        st.code(db_message)

st.markdown("#### Можно нажать готовый пример")
example_columns = st.columns(3)
for index, example in enumerate(EXAMPLES[domain]):
    if example_columns[index].button(example, width="stretch", key=f"example-{domain}-{index}"):
        st.session_state.question = example

with st.form("question-form", clear_on_submit=False):
    question = st.text_area(
        "Ваш вопрос",
        key="question",
        height=110,
        placeholder="Например: покажи пять клиентов с самой большой суммой заказов",
    )
    submitted = st.form_submit_button("Найти ответ", type="primary", width="stretch")

if submitted:
    if not question.strip():
        st.warning("Сначала напишите вопрос.")
    elif not db_ok:
        st.error("Сначала запустите базу данных через Docker Desktop.")
    elif provider == "openai" and not api_key and not os.getenv("LLM_API_KEY"):
        st.error("Вставьте API-ключ в боковой панели слева.")
    else:
        try:
            with st.spinner("Составляю SQL и проверяю результат…"):
                config = _config(provider, model, base_url, api_key)
                pipeline = Text2SQLPipeline(str(ROOT), config)
                result_data = run_question(pipeline, config, domain, question.strip())
            st.session_state.history.insert(0, result_data)
        except (LLMError, ValueError, RuntimeError, OSError) as exc:
            st.error(f"Ошибка: {exc}")

if st.session_state.history:
    _render_result(st.session_state.history[0])
    if len(st.session_state.history) > 1:
        with st.expander(f"История запросов ({len(st.session_state.history) - 1})"):
            for old in st.session_state.history[1:10]:
                st.markdown(f"**{DOMAIN_LABELS.get(old['domain'], old['domain'])}:** {old['question']}")
                st.code(old["generated_sql"], language="sql")

st.divider()
st.caption("Text2SQL · PostgreSQL · запросы выполняются от пользователя только для чтения")
