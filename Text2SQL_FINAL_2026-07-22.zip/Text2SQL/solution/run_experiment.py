#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from evaluate import FIELDS, evaluate
from src.config import Config
from src.error_analysis import write_error_report


EXPERIMENTS = {
    "E01": {"few_shot_mode": "zero", "schema_linking": False, "validation": False, "self_correction": False},
    "E02": {"few_shot_mode": "zero", "schema_linking": True, "validation": False, "self_correction": False},
    "E03": {"few_shot_mode": "static", "schema_linking": False, "validation": False, "self_correction": False},
    "E04": {"few_shot_mode": "retrieval", "schema_linking": True, "validation": False, "self_correction": False},
    "E05": {"few_shot_mode": "retrieval", "schema_linking": True, "validation": True, "self_correction": False},
    "E06": {"few_shot_mode": "retrieval", "schema_linking": True, "validation": True, "self_correction": True},
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--provider", choices=["mock", "openai", "ollama"], default="mock")
    parser.add_argument("--model")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--experiments", nargs="*", choices=sorted(EXPERIMENTS), default=sorted(EXPERIMENTS))
    args = parser.parse_args()
    output_dir = Path(__file__).parent / "outputs"; output_dir.mkdir(exist_ok=True)
    all_rows: list[dict[str, object]] = []
    summary: list[dict[str, object]] = []
    for experiment_id in args.experiments:
        settings = EXPERIMENTS[experiment_id]
        config = Config.from_file(None, provider=args.provider, model=args.model, **settings)
        rows = evaluate(config, output_dir / f"{experiment_id.lower()}_results.csv", experiment_id, args.limit, args.execute)
        all_rows.extend(rows)
        executed = [row["execution_correct"] for row in rows if row["execution_correct"] is not None]
        latencies = [float(row["latency_seconds"]) for row in rows]
        summary.append({"experiment_id": experiment_id, "model": config.model, "rows": len(rows), "exact_match": sum(bool(x["exact_match"]) for x in rows) / len(rows) if rows else 0, "valid_sql_rate": sum(bool(x["valid_sql"]) for x in rows) / len(rows) if rows else 0, "execution_accuracy": sum(bool(x) for x in executed) / len(executed) if executed else "unavailable", "jaccard_similarity": statistics.mean(float(x["jaccard_similarity"]) for x in rows) if rows else 0, "latency_mean_seconds": statistics.mean(latencies) if latencies else 0, "latency_median_seconds": statistics.median(latencies) if latencies else 0})
        print(f"{experiment_id}: {len(rows)} rows")
    with (output_dir / "experiment_results.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS); writer.writeheader(); writer.writerows(all_rows)
    with (output_dir / "metrics_summary.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary[0]) if summary else ["experiment_id"]); writer.writeheader(); writer.writerows(summary)
    write_error_report(output_dir / "experiment_results.csv", output_dir / "ERROR_ANALYSIS.md")
    if not args.execute:
        print("Execution Accuracy = unavailable: PostgreSQL execution was not requested.")


if __name__ == "__main__":
    main()

