#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from app import ROOT, run_question
from src.config import Config
from src.generator import Text2SQLPipeline


QUESTIONS = {
    "01_trading_company": ["Покажи топ-5 покупателей по общей сумме заказов", "Сколько заказов было оформлено в 2023 году?", "Какие товары продаются лучше всего?"],
    "02_legal_firm": ["Какие юристы ведут больше всего дел?", "Покажи неоплаченные счета", "Сколько судебных заседаний было в 2023 году?"],
    "03_logistics_company": ["Какие маршруты используются чаще всего?", "Покажи пять водителей с наибольшим числом перевозок", "Какой общий вес перевезённых грузов?"],
    "04_mining_company": ["Какие рудники добыли больше всего сырья?", "Покажи оборудование, находящееся на ремонте", "Какой минерал добывается чаще всего?"],
    "05_oil_company": ["Какие скважины дают наибольшую добычу?", "Покажи объём добычи по месторождениям", "Какие платформы сейчас активны?"],
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--provider", choices=["mock", "openai", "ollama"], default="mock")
    parser.add_argument("--require-execution", action="store_true")
    args = parser.parse_args()
    config = Config.from_file(None, provider=args.provider, model="mock-test-fixtures" if args.provider == "mock" else None)
    pipeline = Text2SQLPipeline(str(ROOT), config)
    results = []
    for domain, questions in QUESTIONS.items():
        for question in questions:
            data = run_question(pipeline, config, domain, question)
            results.append(data)
            print(f"{domain}: valid={data['valid_sql']} execution={data['execution_status']} rows={data['row_count']}")
    output = Path(__file__).parent / "outputs/smoke_test_results.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    invalid = [x for x in results if not x["valid_sql"]]
    failed = [x for x in results if x["execution_status"] != "success"]
    print(f"Saved {len(results)} results to {output}")
    if invalid or (args.require_execution and failed):
        raise SystemExit(f"Smoke test failed: invalid={len(invalid)}, execution_failed={len(failed)}")


if __name__ == "__main__":
    main()
