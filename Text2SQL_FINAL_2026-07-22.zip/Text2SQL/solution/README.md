# Text2SQL end-to-end MVP

## Быстрый запуск

Требования: Python 3.9+ и запущенный Docker Desktop.

```bash
cd "/Users/pmapmapm/Documents/large larping machine/Text2SQL"
chmod +x setup.sh run.sh
./setup.sh
./start_app.sh
```

На macOS тот же запуск выполняется двойным кликом по корневому файлу `START_TEXT2SQL.command`. Откроется браузерный интерфейс на `http://localhost:8501`.

`setup.sh` создаёт virtual environment, устанавливает зависимости, генерирует SQL-данные, поднимает пять PostgreSQL-контейнеров, создаёт read-only пользователя, проверяет таблицы/строки, запускает тесты и 15 execution smoke-тестов.

Если команда сообщает `Docker не установлен`, установите [Docker Desktop](https://www.docker.com/products/docker-desktop/), откройте приложение и повторите `./setup.sh`.

## Что возвращает приложение

```bash
./run.sh \
  --domain 01_trading_company \
  --question "Покажи топ-5 покупателей по общей сумме заказов"
```

Результат содержит модель, SQL, статус валидации, статус выполнения, реальные строки PostgreSQL, русский текстовый ответ, latency и историю correction.

JSON:

```bash
./run.sh \
  --domain 01_trading_company \
  --question "Покажи топ-5 покупателей по общей сумме заказов" \
  --json
```

## Интерактивный режим

```bash
./run.sh
```

Программа предложит выбрать домен. Команды внутри приложения:

- `/domains` — сменить домен;
- `/schema` — показать таблицы и колонки;
- `/quit` — выйти.

## Настройка настоящей LLM

Приложение автоматически читает `solution/.env`. Ключи нельзя добавлять в код или Git.

### OpenAI-compatible API

Откройте `solution/.env` и заполните:

```dotenv
LLM_PROVIDER=openai
LLM_API_KEY=ваш_ключ
LLM_BASE_URL=https://api.openai.com/v1
LLM_MODEL=gpt-5.6-sol
```

Затем:

```bash
./run.sh --domain 01_trading_company --question "Сколько заказов было оформлено в 2023 году?"
```

### Ollama

```dotenv
LLM_PROVIDER=ollama
LLM_BASE_URL=http://localhost:11434
LLM_MODEL=qwen2.5-coder:7b
LLM_API_KEY=
```

После установки модели и запуска Ollama:

```bash
./run.sh --domain 05_oil_company --question "Какие скважины дают наибольшую добычу?"
```

### Mock

Mock используется только для тестов и 15 заранее определённых smoke fixtures:

```bash
LLM_PROVIDER=mock ./run.sh \
  --domain 01_trading_company \
  --question "Покажи топ-5 покупателей по общей сумме заказов"
```

CLI всегда предупреждает:

```text
WARNING: mock provider does not use an LLM and returns test fixtures.
```

Неизвестный mock-вопрос возвращает `SELECT 1`; mock не следует выдавать за интеллектуальную систему.

## PostgreSQL

`docker-compose.yml` создаёт пять независимых PostgreSQL 16 сервисов:

| Домен | База | Порт |
|---|---|---:|
| trading | `trading` | 55431 |
| legal | `legal` | 55432 |
| logistics | `logistics` | 55433 |
| mining | `mining` | 55434 |
| oil | `oil` | 55435 |

LLM-запросы выполняются пользователем `text2sql_reader`, у которого только `SELECT`, `default_transaction_read_only=on` и statement timeout 5 секунд. Интерактивный интерфейс возвращает максимум 100 строк; evaluator запрашивает полный результат для корректного EX.

Проверка состояния:

```bash
docker compose ps
.venv/bin/python solution/db/check_databases.py
```

Отчёт: `solution/outputs/database_status.json`.

Остановить контейнеры без удаления данных:

```bash
docker compose stop
```

Исходные `databases/` не меняются. `solution/db/build_data.py` исправляет две известные ошибки генераторов только во временной копии: синтаксис legal generator и некорректные даты `product_prices`.

## Валидация и self-correction

Перед выполнением `sqlglot` проверяет:

- один statement;
- только `SELECT` или `WITH ... SELECT`;
- отсутствие DDL/DML;
- существование таблиц и колонок.

При SQL-ошибке PostgreSQL модель получает исходный SQL, ошибку и схему. Допускается максимум две correction-попытки. Ошибка подключения к PostgreSQL не отправляется модели как ошибка SQL.

## Evaluation

Полная evaluation на public split с реальным выполнением predicted и gold SQL:

```bash
.venv/bin/python solution/evaluate.py \
  --split public \
  --provider openai \
  --output solution/outputs/public_results.csv
```

Для короткой проверки:

```bash
.venv/bin/python solution/evaluate.py --split public --provider mock --limit 15
```

Результаты:

- `solution/outputs/public_results.csv`;
- `solution/outputs/public_metrics.json`.

Считаются raw Exact Match, normalized Exact Match, Valid SQL Rate, Execution Accuracy, Jaccard, latency, correction count, failure reason, `Score_d` и `FinalScore`. VSR требует успешной AST-проверки и выполнения. Ошибки дают `EX=0` и входят в общий знаменатель; predicted и gold сравниваются по полным результатам. JSON содержит overall, домены, уровни сложности, типы SQL и частые ошибки.

## Submission

```bash
.venv/bin/python solution/create_submission.py \
  --split public \
  --provider openai \
  --output submission.csv
```

В submission записываются только `domain,id,predicted_sql`. `gold_sql` не передаётся pipeline и не используется для генерации.

## Smoke-тесты пяти доменов

```bash
LLM_PROVIDER=mock .venv/bin/python solution/smoke_test.py \
  --provider mock \
  --require-execution
```

Проверяются три вопроса для каждого из пяти доменов. Результаты: `solution/outputs/smoke_test_results.json`.

## Unit-тесты

```bash
.venv/bin/pytest -q solution/tests
```

## Ограничения

- Для настоящей LLM нужен API-ключ либо запущенный Ollama с моделью.
- Синтетические данные и вопросы benchmark содержат смысловые дефекты, описанные в `REPOSITORY_AUDIT.md`.
- Private split исходного архива скомпрометирован; его score нельзя считать честным leaderboard-результатом.
- Детерминированный текстовый ответ строится только из возвращённых строк и ничего не выдумывает.
