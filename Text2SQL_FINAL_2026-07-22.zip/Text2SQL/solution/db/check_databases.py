#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.config import load_dotenv
from src.sql_executor import dsn_for_domain


DOMAINS = ["01_trading_company", "02_legal_firm", "03_logistics_company", "04_mining_company", "05_oil_company"]


def main() -> None:
    import psycopg
    load_dotenv()
    report = {}
    for domain in DOMAINS:
        dsn = dsn_for_domain(domain)
        if not dsn:
            raise SystemExit(f"DSN missing for {domain}")
        with psycopg.connect(dsn) as conn, conn.cursor() as cur:
            cur.execute("SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename")
            tables = [row[0] for row in cur.fetchall()]
            counts = {}
            for table in tables:
                cur.execute(f'SELECT COUNT(*) FROM "{table}"')
                counts[table] = cur.fetchone()[0]
            report[domain] = {"table_count": len(tables), "total_rows": sum(counts.values()), "tables": counts}
            print(f"{domain}: {len(tables)} tables, {sum(counts.values()):,} rows")
    output = Path(__file__).resolve().parents[1] / "outputs/database_status.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Saved {output}")


if __name__ == "__main__":
    main()

