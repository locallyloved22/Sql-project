DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'text2sql_reader') THEN
        CREATE ROLE text2sql_reader LOGIN PASSWORD 'text2sql_reader';
    END IF;
END
$$;
DO $$
BEGIN
    EXECUTE format('GRANT CONNECT ON DATABASE %I TO text2sql_reader', current_database());
END
$$;
GRANT USAGE ON SCHEMA public TO text2sql_reader;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO text2sql_reader;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO text2sql_reader;
ALTER ROLE text2sql_reader SET default_transaction_read_only = on;
ALTER ROLE text2sql_reader SET statement_timeout = '5s';
