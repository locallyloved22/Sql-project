#!/usr/bin/env python3
"""Генерирует data.sql вне исходного датасета, не изменяя databases/."""
from __future__ import annotations

import argparse
import shutil
import subprocess
import tempfile
from pathlib import Path


DOMAINS = ["01_trading_company", "02_legal_firm", "03_logistics_company", "04_mining_company", "05_oil_company"]


def fix_trading_source(source: str) -> str:
    old = """                    valid_to = f\"{year}-{month+5 if month==1 else year+1}-01-01\" if (year, month) != (2025, 1) else 'NULL'
                    f.write(f\"INSERT INTO product_prices (product_id, price, valid_from, valid_to, price_type) VALUES ({prod}, {round(price, 2)}, '{valid_from}', {valid_to if valid_to != 'NULL' else 'NULL'}, '{random.choice(['retail', 'wholesale'])}');\\n\")"""
    new = """                    if (year, month) == (2025, 1):
                        valid_to = 'NULL'
                    elif month == 1:
                        valid_to = f\"'{year}-06-01'\"
                    else:
                        valid_to = f\"'{year + 1}-01-01'\"
                    f.write(f\"INSERT INTO product_prices (product_id, price, valid_from, valid_to, price_type) VALUES ({prod}, {round(price, 2)}, '{valid_from}', {valid_to}, '{random.choice(['retail', 'wholesale'])}');\\n\")"""
    if old not in source:
        raise RuntimeError("Не удалось применить исправление trading product_prices")
    return source.replace(old, new)


def fix_legal_source(source: str) -> str:
    old = """        f.write(f\"INSERT INTO cases (case_id, case_number, case_title, client_id, practice_area_id, case_type, status, court_id, filing_date, closing_date, estimated_value) VALUES ({i}, 'ДЕЛО-{i:05d}', 'Дело_{i}', {random.randint(1,2000)}, {random.randint(1,15)}, '{random.choice(['civil','criminal','arbitration','corporate'])}', '{status}', {random.randint(1,30)}, '{rd(2020,2024)}', {f\\\"'{rd(2021,2025)}'\\\" if status in ['won','lost','settled','closed'] else 'NULL'}, {random.randint(100000,50000000)});\\n\")"""
    new = """        closing = f\"'{rd(2021,2025)}'\" if status in ['won','lost','settled','closed'] else 'NULL'
        f.write(f\"INSERT INTO cases (case_id, case_number, case_title, client_id, practice_area_id, case_type, status, court_id, filing_date, closing_date, estimated_value) VALUES ({i}, 'ДЕЛО-{i:05d}', 'Дело_{i}', {random.randint(1,2000)}, {random.randint(1,15)}, '{random.choice(['civil','criminal','arbitration','corporate'])}', '{status}', {random.randint(1,30)}, '{rd(2020,2024)}', {closing}, {random.randint(100000,50000000)});\\n\")"""
    if old not in source:
        raise RuntimeError("Не удалось применить известное исправление legal generator")
    return source.replace(old, new)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository-root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "generated")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="text2sql-data-") as tmp_name:
        tmp = Path(tmp_name)
        for domain in DOMAINS:
            work = tmp / domain
            work.mkdir()
            source = (args.repository_root / "databases" / domain / "generate_data.py").read_text(encoding="utf-8")
            if domain == "01_trading_company":
                source = fix_trading_source(source)
            if domain == "02_legal_firm":
                source = fix_legal_source(source)
            generator = work / "generate_data.py"
            generator.write_text(source, encoding="utf-8")
            subprocess.run([str(Path(__import__('sys').executable)), str(generator)], check=True, cwd=work)
            data = work / "data.sql"
            if not data.exists() or data.stat().st_size == 0:
                raise RuntimeError(f"{domain}: generator did not create data.sql")
            target = args.output / f"{domain}.sql"
            shutil.copy2(data, target)
            print(f"{domain}: {target.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()
