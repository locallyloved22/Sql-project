# Error analysis

| Тип ошибки | Количество |
|---|---:|
| `wrong_table` | 54 |
| `wrong_aggregation` | 3 |
| `wrong_filter` | 3 |
