-- ============================================
-- БАЗА ДАННЫХ: ГОРНОРУДНАЯ КОМПАНИЯ
-- ============================================

-- Справочники
CREATE TABLE mineral_types (
    mineral_type_id SERIAL PRIMARY KEY,
    mineral_name VARCHAR(100) NOT NULL,
    chemical_formula VARCHAR(50),
    unit_of_measure VARCHAR(20),
    market_price_per_unit DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE deposit_types (
    deposit_type_id SERIAL PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL,
    description TEXT,
    typical_depth_m INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE mines (
    mine_id SERIAL PRIMARY KEY,
    mine_code VARCHAR(20) UNIQUE NOT NULL,
    mine_name VARCHAR(100) NOT NULL,
    location VARCHAR(200),
    region VARCHAR(100),
    country VARCHAR(50),
    latitude DECIMAL(10,6),
    longitude DECIMAL(10,6),
    deposit_type_id INT REFERENCES deposit_types(deposit_type_id),
    opening_date DATE,
    status VARCHAR(30) CHECK (status IN ('exploration', 'development', 'operational', 'suspended', 'closed')),
    capacity_annual_tonnes DECIMAL(14,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE mine_minerals (
    mm_id SERIAL PRIMARY KEY,
    mine_id INT NOT NULL REFERENCES mines(mine_id),
    mineral_type_id INT NOT NULL REFERENCES mineral_types(mineral_type_id),
    estimated_reserves_tonnes DECIMAL(14,2),
    average_grade_percent DECIMAL(6,3),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE equipment_types (
    equipment_type_id SERIAL PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) CHECK (category IN ('excavator', 'haul_truck', 'drill', 'crusher', 'conveyor', 'processing')),
    capacity_tonnes_per_hour DECIMAL(10,2),
    fuel_consumption_lph DECIMAL(8,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE equipment (
    equipment_id SERIAL PRIMARY KEY,
    equipment_code VARCHAR(20) UNIQUE NOT NULL,
    equipment_type_id INT NOT NULL REFERENCES equipment_types(equipment_type_id),
    mine_id INT REFERENCES mines(mine_id),
    purchase_date DATE,
    purchase_cost DECIMAL(14,2),
    status VARCHAR(30) CHECK (status IN ('operational', 'maintenance', 'standby', 'decommissioned')),
    total_operating_hours DECIMAL(12,2) DEFAULT 0,
    last_maintenance_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE departments (
    department_id SERIAL PRIMARY KEY,
    department_name VARCHAR(100) NOT NULL,
    department_type VARCHAR(50) CHECK (department_type IN ('mining', 'processing', 'maintenance', 'safety', 'admin', 'logistics')),
    mine_id INT REFERENCES mines(mine_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE employees (
    employee_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    department_id INT REFERENCES departments(department_id),
    position VARCHAR(100),
    hire_date DATE,
    salary DECIMAL(12,2),
    certification VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Добыча
CREATE TABLE extraction_sites (
    site_id SERIAL PRIMARY KEY,
    mine_id INT NOT NULL REFERENCES mines(mine_id),
    site_name VARCHAR(100) NOT NULL,
    site_code VARCHAR(20),
    depth_m INT,
    status VARCHAR(20) CHECK (status IN ('active', 'depleted', 'planned')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE extraction_records (
    record_id SERIAL PRIMARY KEY,
    mine_id INT NOT NULL REFERENCES mines(mine_id),
    site_id INT REFERENCES extraction_sites(site_id),
    mineral_type_id INT NOT NULL REFERENCES mineral_types(mineral_type_id),
    extraction_date DATE NOT NULL,
    ore_tonnes DECIMAL(12,3) NOT NULL,
    grade_percent DECIMAL(6,3),
    concentrate_tonnes DECIMAL(12,3),
    shift_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Обработка
CREATE TABLE processing_plants (
    plant_id SERIAL PRIMARY KEY,
    plant_name VARCHAR(100) NOT NULL,
    mine_id INT REFERENCES mines(mine_id),
    capacity_tonnes_per_day DECIMAL(12,2),
    process_type VARCHAR(50) CHECK (process_type IN ('crushing', 'grinding', 'flotation', 'leaching', 'smelting')),
    status VARCHAR(20) CHECK (status IN ('operational', 'maintenance', 'closed')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE processing_records (
    pr_id SERIAL PRIMARY KEY,
    plant_id INT NOT NULL REFERENCES processing_plants(plant_id),
    input_mineral_type_id INT REFERENCES mineral_types(mineral_type_id),
    output_mineral_type_id INT REFERENCES mineral_types(mineral_type_id),
    process_date DATE NOT NULL,
    input_tonnes DECIMAL(12,3),
    output_tonnes DECIMAL(12,3),
    recovery_rate_percent DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Продажи
CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    customer_name VARCHAR(200) NOT NULL,
    country VARCHAR(50),
    contact_person VARCHAR(100),
    email VARCHAR(100),
    contract_type VARCHAR(30),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sales_contracts (
    contract_id SERIAL PRIMARY KEY,
    contract_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT NOT NULL REFERENCES customers(customer_id),
    mineral_type_id INT NOT NULL REFERENCES mineral_types(mineral_type_id),
    contract_date DATE,
    start_date DATE,
    end_date DATE,
    quantity_tonnes DECIMAL(14,2),
    price_per_tonne DECIMAL(12,2),
    delivery_terms VARCHAR(50),
    status VARCHAR(20) CHECK (status IN ('draft', 'active', 'fulfilled', 'cancelled')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE shipments (
    shipment_id SERIAL PRIMARY KEY,
    shipment_number VARCHAR(50) UNIQUE NOT NULL,
    contract_id INT REFERENCES sales_contracts(contract_id),
    mineral_type_id INT NOT NULL REFERENCES mineral_types(mineral_type_id),
    shipment_date DATE,
    quantity_tonnes DECIMAL(12,3),
    quality_grade VARCHAR(20),
    destination VARCHAR(200),
    status VARCHAR(30) CHECK (status IN ('planned', 'loaded', 'in_transit', 'delivered')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Безопасность
CREATE TABLE safety_incidents (
    incident_id SERIAL PRIMARY KEY,
    mine_id INT NOT NULL REFERENCES mines(mine_id),
    incident_date DATE NOT NULL,
    incident_type VARCHAR(50) CHECK (incident_type IN ('injury', 'near_miss', 'equipment_damage', 'environmental', 'fatal')),
    severity VARCHAR(20) CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    description TEXT,
    department_id INT REFERENCES departments(department_id),
    injured_employee_id INT REFERENCES employees(employee_id),
    lost_time_days INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE safety_trainings (
    training_id SERIAL PRIMARY KEY,
    training_name VARCHAR(200) NOT NULL,
    training_date DATE NOT NULL,
    mine_id INT REFERENCES mines(mine_id),
    instructor VARCHAR(100),
    duration_hours DECIMAL(4,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE training_attendance (
    attendance_id SERIAL PRIMARY KEY,
    training_id INT NOT NULL REFERENCES safety_trainings(training_id),
    employee_id INT NOT NULL REFERENCES employees(employee_id),
    passed BOOLEAN DEFAULT TRUE,
    score DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Экология
CREATE TABLE environmental_monitoring (
    monitoring_id SERIAL PRIMARY KEY,
    mine_id INT NOT NULL REFERENCES mines(mine_id),
    monitoring_date DATE NOT NULL,
    parameter_type VARCHAR(50) CHECK (parameter_type IN ('water_quality', 'air_quality', 'noise', 'waste', 'reclamation')),
    parameter_value DECIMAL(12,4),
    unit VARCHAR(20),
    limit_value DECIMAL(12,4),
    within_limits BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Затраты
CREATE TABLE operating_costs (
    cost_id SERIAL PRIMARY KEY,
    mine_id INT NOT NULL REFERENCES mines(mine_id),
    cost_date DATE NOT NULL,
    cost_category VARCHAR(50) CHECK (cost_category IN ('labor', 'fuel', 'explosives', 'maintenance', 'utilities', 'materials', 'other')),
    amount DECIMAL(14,2) NOT NULL,
    description TEXT,
    department_id INT REFERENCES departments(department_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
