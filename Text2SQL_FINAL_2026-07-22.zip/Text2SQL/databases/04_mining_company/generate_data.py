"""Генерация данных для горнорудной компании. 2020-2025."""
import random
from datetime import datetime, timedelta
from pathlib import Path

OUTPUT = Path(__file__).parent / 'data.sql'
random.seed(44)

def rd(sy=2020, ey=2025):
    s, e = datetime(sy,1,1), datetime(ey,12,31)
    return (s + timedelta(days=random.randint(0,(e-s).days))).strftime('%Y-%m-%d')

with open(OUTPUT, 'w', encoding='utf-8') as f:
    # Mineral types
    minerals = ['Железная руда', 'Медь', 'Золото', 'Уголь', 'Никель', 'Цинк', 'Алюминий', 'Уран', 'Фосфаты', 'Калий']
    for i, m in enumerate(minerals, 1):
        f.write(f"INSERT INTO mineral_types (mineral_type_id, mineral_name, unit_of_measure, market_price_per_unit) VALUES ({i}, '{m}', 'тонна', {random.randint(50,5000)});\n")
    
    # Deposit types
    for i in range(1, 6):
        f.write(f"INSERT INTO deposit_types (deposit_type_id, type_name, typical_depth_m) VALUES ({i}, 'Тип_{i}', {random.randint(100,1500)});\n")
    
    # Mines (15)
    regions = ['Урал', 'Сибирь', 'Дальний Восток', 'Кузбасс', 'Кольский']
    for i in range(1, 16):
        f.write(f"INSERT INTO mines (mine_id, mine_code, mine_name, region, status, capacity_annual_tonnes) VALUES ({i}, 'M-{i:02d}', 'Рудник_{i}', '{random.choice(regions)}', 'operational', {random.randint(100000,5000000)});\n")
    
    # Mine minerals
    for m in range(1, 16):
        for _ in range(random.randint(1, 4)):
            min_id = random.randint(1, 10)
            f.write(f"INSERT INTO mine_minerals (mine_id, mineral_type_id, estimated_reserves_tonnes, average_grade_percent) VALUES ({m}, {min_id}, {random.randint(1000000,100000000)}, {round(random.uniform(0.5,15), 2)});\n")
    
    # Equipment (100)
    for i in range(1, 11):
        f.write(f"INSERT INTO equipment_types (equipment_type_id, type_name, category, capacity_tonnes_per_hour) VALUES ({i}, 'Тип_{i}', '{random.choice(['excavator','haul_truck','drill','crusher'])}', {random.randint(50,500)});\n")
    for i in range(1, 101):
        f.write(f"INSERT INTO equipment (equipment_id, equipment_code, equipment_type_id, mine_id, status, total_operating_hours) VALUES ({i}, 'EQ-{i:03d}', {random.randint(1,10)}, {random.randint(1,15)}, '{random.choice(['operational','maintenance','standby'])}', {random.randint(1000,50000)});\n")
    
    # Departments & Employees
    for i in range(1, 31):
        f.write(f"INSERT INTO departments (department_id, department_name, department_type, mine_id) VALUES ({i}, 'Отдел_{i}', '{random.choice(['mining','processing','maintenance','safety'])}', {random.randint(1,15)});\n")
    for i in range(1, 301):
        f.write(f"INSERT INTO employees (employee_id, first_name, last_name, department_id, position, hire_date, salary) VALUES ({i}, 'Работник_{i}', 'Фамилия', {random.randint(1,30)}, 'Специалист', '{rd(2015,2023)}', {random.randint(50000,200000)});\n")
    
    # Extraction records (10000 - ежедневные за 5 лет)
    for _ in range(10000):
        f.write(f"INSERT INTO extraction_records (mine_id, mineral_type_id, extraction_date, ore_tonnes, grade_percent, concentrate_tonnes) VALUES ({random.randint(1,15)}, {random.randint(1,10)}, '{rd(2020,2025)}', {round(random.uniform(100,5000), 2)}, {round(random.uniform(1,20), 2)}, {round(random.uniform(50,2000), 2)});\n")
    
    # Processing (20 plants)
    for i in range(1, 21):
        f.write(f"INSERT INTO processing_plants (plant_id, plant_name, mine_id, capacity_tonnes_per_day, process_type, status) VALUES ({i}, 'Фабрика_{i}', {random.randint(1,15)}, {random.randint(1000,10000)}, '{random.choice(['crushing','grinding','flotation'])}', 'operational');\n")
    
    # Processing records (5000)
    for i in range(1, 5001):
        f.write(f"INSERT INTO processing_records (plant_id, input_mineral_type_id, output_mineral_type_id, process_date, input_tonnes, output_tonnes, recovery_rate_percent) VALUES ({random.randint(1,20)}, {random.randint(1,10)}, {random.randint(1,10)}, '{rd(2020,2025)}', {round(random.uniform(100,2000), 2)}, {round(random.uniform(80,1800), 2)}, {round(random.uniform(70,98), 2)});\n")
    
    # Customers & Sales
    for i in range(1, 51):
        f.write(f"INSERT INTO customers (customer_id, customer_name, country, contract_type) VALUES ({i}, 'Покупатель_{i}', '{random.choice(['Россия','Китай','Европа'])}', 'Долгосрочный');\n")
    for i in range(1, 201):
        f.write(f"INSERT INTO sales_contracts (contract_id, contract_number, customer_id, mineral_type_id, contract_date, quantity_tonnes, price_per_tonne, status) VALUES ({i}, 'CNT-{i:04d}', {random.randint(1,50)}, {random.randint(1,10)}, '{rd(2020,2024)}', {random.randint(10000,500000)}, {random.randint(100,2000)}, '{random.choice(['active','fulfilled'])}');\n")
    
    # Shipments (3000)
    for i in range(1, 3001):
        f.write(f"INSERT INTO shipments (shipment_id, shipment_number, contract_id, mineral_type_id, shipment_date, quantity_tonnes, status) VALUES ({i}, 'SHP-{i:05d}', {random.randint(1,200)}, {random.randint(1,10)}, '{rd(2020,2025)}', {round(random.uniform(1000,50000), 2)}, '{random.choice(['planned','loaded','in_transit','delivered'])}');\n")
    
    # Safety (500 incidents, 200 trainings)
    for i in range(1, 501):
        f.write(f"INSERT INTO safety_incidents (incident_id, mine_id, incident_date, incident_type, severity, lost_time_days) VALUES ({i}, {random.randint(1,15)}, '{rd(2020,2025)}', '{random.choice(['injury','near_miss','equipment_damage'])}', '{random.choice(['low','medium','high'])}', {random.randint(0,30)});\n")
    for i in range(1, 201):
        f.write(f"INSERT INTO safety_trainings (training_id, training_name, training_date, mine_id, duration_hours) VALUES ({i}, 'Обучение_{i}', '{rd(2020,2025)}', {random.randint(1,15)}, {random.randint(2,8)});\n")
    
    # Operating costs (8000)
    for i in range(1, 8001):
        f.write(f"INSERT INTO operating_costs (cost_id, mine_id, cost_date, cost_category, amount, department_id) VALUES ({i}, {random.randint(1,15)}, '{rd(2020,2025)}', '{random.choice(['labor','fuel','maintenance','utilities'])}', {random.randint(10000,500000)}, {random.randint(1,30)});\n")

print("Mining data generated.")
