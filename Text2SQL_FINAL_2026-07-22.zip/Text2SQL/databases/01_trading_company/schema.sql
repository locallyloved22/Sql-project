-- ============================================
-- БАЗА ДАННЫХ: ТОРГОВАЯ КОМПАНИЯ
-- Широкий спектр товаров (B2B и B2C)
-- ============================================

-- Справочники
CREATE TABLE categories (
    category_id SERIAL PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    parent_category_id INT REFERENCES categories(category_id),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE subcategories (
    subcategory_id SERIAL PRIMARY KEY,
    category_id INT NOT NULL REFERENCES categories(category_id),
    subcategory_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE brands (
    brand_id SERIAL PRIMARY KEY,
    brand_name VARCHAR(100) NOT NULL,
    country_of_origin VARCHAR(50),
    founded_year INT,
    website VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE suppliers (
    supplier_id SERIAL PRIMARY KEY,
    supplier_name VARCHAR(200) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(50),
    tax_id VARCHAR(50),
    bank_details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE warehouses (
    warehouse_id SERIAL PRIMARY KEY,
    warehouse_name VARCHAR(100) NOT NULL,
    address TEXT,
    city VARCHAR(100),
    region VARCHAR(100),
    capacity_sqm DECIMAL(12,2),
    manager_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    customer_type VARCHAR(20) CHECK (customer_type IN ('B2B', 'B2C')),
    company_name VARCHAR(200),
    contact_name VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    city VARCHAR(100),
    region VARCHAR(100),
    country VARCHAR(50),
    tax_id VARCHAR(50),
    discount_tier VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE employees (
    employee_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    position VARCHAR(100),
    department VARCHAR(100),
    hire_date DATE,
    salary DECIMAL(12,2),
    manager_id INT REFERENCES employees(employee_id),
    warehouse_id INT REFERENCES warehouses(warehouse_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Товары и цены
CREATE TABLE products (
    product_id SERIAL PRIMARY KEY,
    product_code VARCHAR(50) UNIQUE NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    subcategory_id INT REFERENCES subcategories(subcategory_id),
    brand_id INT REFERENCES brands(brand_id),
    unit_of_measure VARCHAR(20),
    weight_kg DECIMAL(10,3),
    dimensions VARCHAR(50),
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE product_prices (
    price_id SERIAL PRIMARY KEY,
    product_id INT NOT NULL REFERENCES products(product_id),
    price DECIMAL(12,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'RUB',
    valid_from DATE NOT NULL,
    valid_to DATE,
    price_type VARCHAR(20) CHECK (price_type IN ('retail', 'wholesale', 'promo')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Закупки
CREATE TABLE purchase_orders (
    po_id SERIAL PRIMARY KEY,
    po_number VARCHAR(50) UNIQUE NOT NULL,
    supplier_id INT NOT NULL REFERENCES suppliers(supplier_id),
    order_date DATE NOT NULL,
    expected_delivery_date DATE,
    actual_delivery_date DATE,
    status VARCHAR(30) CHECK (status IN ('draft', 'sent', 'confirmed', 'partial', 'received', 'cancelled')),
    total_amount DECIMAL(14,2),
    currency VARCHAR(3) DEFAULT 'RUB',
    created_by INT REFERENCES employees(employee_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE purchase_order_items (
    poi_id SERIAL PRIMARY KEY,
    po_id INT NOT NULL REFERENCES purchase_orders(po_id),
    product_id INT NOT NULL REFERENCES products(product_id),
    quantity DECIMAL(12,3) NOT NULL,
    unit_price DECIMAL(12,2) NOT NULL,
    received_quantity DECIMAL(12,3) DEFAULT 0,
    warehouse_id INT REFERENCES warehouses(warehouse_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Продажи
CREATE TABLE sales_orders (
    order_id SERIAL PRIMARY KEY,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT NOT NULL REFERENCES customers(customer_id),
    order_date DATE NOT NULL,
    required_date DATE,
    shipped_date DATE,
    status VARCHAR(30) CHECK (status IN ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
    sales_rep_id INT REFERENCES employees(employee_id),
    warehouse_id INT REFERENCES warehouses(warehouse_id),
    total_amount DECIMAL(14,2),
    discount_percent DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sales_order_items (
    soi_id SERIAL PRIMARY KEY,
    order_id INT NOT NULL REFERENCES sales_orders(order_id),
    product_id INT NOT NULL REFERENCES products(product_id),
    quantity DECIMAL(12,3) NOT NULL,
    unit_price DECIMAL(12,2) NOT NULL,
    discount_percent DECIMAL(5,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Складской учёт
CREATE TABLE inventory (
    inventory_id SERIAL PRIMARY KEY,
    product_id INT NOT NULL REFERENCES products(product_id),
    warehouse_id INT NOT NULL REFERENCES warehouses(warehouse_id),
    quantity DECIMAL(12,3) NOT NULL DEFAULT 0,
    reserved_quantity DECIMAL(12,3) DEFAULT 0,
    min_stock_level DECIMAL(12,3),
    last_count_date DATE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(product_id, warehouse_id)
);

CREATE TABLE inventory_movements (
    movement_id SERIAL PRIMARY KEY,
    product_id INT NOT NULL REFERENCES products(product_id),
    warehouse_id INT NOT NULL REFERENCES warehouses(warehouse_id),
    movement_type VARCHAR(20) CHECK (movement_type IN ('receipt', 'shipment', 'transfer_in', 'transfer_out', 'adjustment', 'write_off')),
    quantity DECIMAL(12,3) NOT NULL,
    reference_type VARCHAR(30),
    reference_id INT,
    movement_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    employee_id INT REFERENCES employees(employee_id),
    notes TEXT
);

-- Возвраты
CREATE TABLE returns (
    return_id SERIAL PRIMARY KEY,
    return_number VARCHAR(50) UNIQUE NOT NULL,
    order_id INT REFERENCES sales_orders(order_id),
    customer_id INT NOT NULL REFERENCES customers(customer_id),
    return_date DATE NOT NULL,
    reason VARCHAR(100),
    status VARCHAR(30) CHECK (status IN ('received', 'inspected', 'refunded', 'rejected')),
    refund_amount DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE return_items (
    ri_id SERIAL PRIMARY KEY,
    return_id INT NOT NULL REFERENCES returns(return_id),
    product_id INT NOT NULL REFERENCES products(product_id),
    quantity DECIMAL(12,3) NOT NULL,
    condition VARCHAR(30),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Платежи
CREATE TABLE payments (
    payment_id SERIAL PRIMARY KEY,
    order_id INT REFERENCES sales_orders(order_id),
    po_id INT REFERENCES purchase_orders(po_id),
    payment_date DATE NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'RUB',
    payment_method VARCHAR(30) CHECK (payment_method IN ('cash', 'card', 'bank_transfer', 'invoice', 'letter_of_credit')),
    status VARCHAR(20) CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
    reference_number VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Промоакции
CREATE TABLE promotions (
    promotion_id SERIAL PRIMARY KEY,
    promotion_name VARCHAR(200) NOT NULL,
    promotion_type VARCHAR(30) CHECK (promotion_type IN ('discount', 'bundle', 'gift', 'cashback')),
    discount_percent DECIMAL(5,2),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE promotion_products (
    pp_id SERIAL PRIMARY KEY,
    promotion_id INT NOT NULL REFERENCES promotions(promotion_id),
    product_id INT NOT NULL REFERENCES products(product_id),
    special_price DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
