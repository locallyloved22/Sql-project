"""
Generation of large-scale data for the trading company database.
Data for the last 5 years.
"""
import random
from datetime import datetime, timedelta
from pathlib import Path

OUTPUT_DIR = Path(__file__).parent
random.seed(42)


def random_date(start_year=2020, end_year=2025):
    start = datetime(start_year, 1, 1)
    end = datetime(end_year, 12, 31)
    delta = (end - start).days
    return (start + timedelta(days=random.randint(0, delta))).strftime('%Y-%m-%d')


def generate_trading_data():
    categories_data = [
        (1, 'Electronics', None, 'Consumer and industrial electronics'),
        (2, 'Clothing and Footwear', None, 'Clothes, shoes, accessories'),
        (3, 'Food Products', None, 'Food goods'),
        (4, 'Furniture', None, 'Home and office furniture'),
        (5, 'Sports Goods', None, 'Sports equipment'),
        (6, 'Stationery', None, 'Office supplies'),
        (7, 'Home Appliances', 1, 'Large and small household appliances'),
        (8, 'Computers', 1, 'PCs, laptops, components'),
        (9, 'Mens Clothing', 2, 'Clothing for men'),
        (10, 'Womens Clothing', 2, 'Clothing for women'),
    ]

    subcategories = []
    for i, (cat_id, name, parent, desc) in enumerate(categories_data[:8], 1):
        for j in range(2, 5):
            subcategories.append((i * 10 + j, i, f'{name} subcategory {j}', desc))

    brands = [f"Brand_{i}" for i in range(1, 51)]
    suppliers = [f"Supplier_{i}" for i in range(1, 81)]
    cities = [
        'Moscow',
        'Saint Petersburg',
        'Novosibirsk',
        'Yekaterinburg',
        'Kazan',
        'Nizhny Novgorod',
        'Samara',
        'Rostov-on-Don',
    ]

    with open(OUTPUT_DIR / 'data.sql', 'w', encoding='utf-8') as f:
        f.write("-- Trading company data generation\n\n")

        # Categories
        for c in categories_data:
            f.write(
                f"INSERT INTO categories (category_id, category_name, parent_category_id, description) VALUES ({c[0]}, '{c[1]}', {str(c[2]) if c[2] else 'NULL'}, '{c[3]}');\n"
            )

        # Subcategories
        for s in subcategories:
            f.write(
                f"INSERT INTO subcategories (subcategory_id, category_id, subcategory_name, description) VALUES ({s[0]}, {s[1]}, '{s[2]}', '{s[3]}');\n"
            )

        # Brands
        for i, b in enumerate(brands, 1):
            f.write(
                f"INSERT INTO brands (brand_id, brand_name, country_of_origin, founded_year) VALUES ({i}, '{b}', '{random.choice(['Russia', 'China', 'Germany', 'Japan', 'USA'])}', {random.randint(1990, 2020)});\n"
            )

        # Suppliers
        for i, s in enumerate(suppliers, 1):
            f.write(
                f"INSERT INTO suppliers (supplier_id, supplier_name, city, country) VALUES ({i}, '{s}', '{random.choice(cities)}', 'Russia');\n"
            )

        # Warehouses
        for i in range(1, 11):
            f.write(
                f"INSERT INTO warehouses (warehouse_id, warehouse_name, city, region, capacity_sqm) VALUES ({i}, 'Warehouse_{i}', '{random.choice(cities)}', 'Central Region', {random.randint(1000, 50000)});\n"
            )

        # Employees
        for i in range(1, 101):
            dept = random.choice(['Sales', 'Purchasing', 'Warehouse', 'Logistics', 'Finance'])
            f.write(
                f"INSERT INTO employees (employee_id, first_name, last_name, position, department, hire_date, salary, warehouse_id) VALUES ({i}, 'FirstName_{i}', 'LastName_{i}', 'Employee', '{dept}', '{random_date(2018, 2023)}', {random.randint(50000, 150000)}, {random.randint(1, 10)});\n"
            )

        # Customers (500 B2B + 2000 B2C)
        for i in range(1, 501):
            f.write(
                f"INSERT INTO customers (customer_id, customer_type, company_name, contact_name, city, country, discount_tier) VALUES ({i}, 'B2B', 'Company_{i}', 'Contact_{i}', '{random.choice(cities)}', 'Russia', '{random.choice(['A', 'B', 'C', 'D'])}');\n"
            )
        for i in range(501, 2501):
            f.write(
                f"INSERT INTO customers (customer_id, customer_type, contact_name, city, country, discount_tier) VALUES ({i}, 'B2C', 'Customer_{i}', '{random.choice(cities)}', 'Russia', 'Standard');\n"
            )

        # Products (2000)
        for i in range(1, 2001):
            subcat = random.choice([s[0] for s in subcategories])
            brand = random.randint(1, 50)
            f.write(
                f"INSERT INTO products (product_id, product_code, product_name, subcategory_id, brand_id, unit_of_measure, weight_kg, is_active) VALUES ({i}, 'PRD-{i:06d}', 'Product_{i}', {subcat}, {brand}, 'pcs', {round(random.uniform(0.1, 50), 2)}, true);\n"
            )

        # Product prices (history for 5 years)
        for prod in range(1, 501):  # Prices for 500 products
            base_price = random.randint(100, 50000)
            for year in range(2020, 2026):
                for month in [1, 6]:
                    if year == 2025 and month == 6:
                        continue
                    price = base_price * (1 + random.uniform(-0.1, 0.3))
                    valid_from = f"{year}-{month:02d}-01"
                    valid_to = f"{year}-{month+5 if month==1 else year+1}-01-01" if (year, month) != (2025, 1) else 'NULL'
                    f.write(
                        f"INSERT INTO product_prices (product_id, price, valid_from, valid_to, price_type) VALUES ({prod}, {round(price, 2)}, '{valid_from}', {valid_to if valid_to != 'NULL' else 'NULL'}, '{random.choice(['retail', 'wholesale'])}');\n"
                    )

        # Purchase orders (5000 over 5 years)
        for i in range(1, 5001):
            supp = random.randint(1, 80)
            ord_date = random_date(2020, 2025)
            status = random.choices(['draft', 'sent', 'confirmed', 'received'], weights=[5, 10, 30, 55])[0]
            total = random.randint(10000, 5000000)
            f.write(
                f"INSERT INTO purchase_orders (po_id, po_number, supplier_id, order_date, status, total_amount, created_by) VALUES ({i}, 'PO-{i:06d}', {supp}, '{ord_date}', '{status}', {total}, {random.randint(1, 100)});\n"
            )

        # Purchase order items (3–15 per order)
        poi_id = 1
        for po in range(1, 5001):
            n_items = random.randint(3, 15)
            for _ in range(n_items):
                prod = random.randint(1, 2000)
                qty = random.randint(1, 500)
                price = random.randint(50, 10000)
                f.write(
                    f"INSERT INTO purchase_order_items (poi_id, po_id, product_id, quantity, unit_price, received_quantity, warehouse_id) VALUES ({poi_id}, {po}, {prod}, {qty}, {price}, {int(qty*random.uniform(0.8, 1))}, {random.randint(1, 10)});\n"
                )
                poi_id += 1

        # Sales orders (30000 over 5 years)
        for i in range(1, 30001):
            cust = random.randint(1, 2500)
            ord_date = random_date(2020, 2025)
            status = random.choices(['pending', 'processing', 'shipped', 'delivered'], weights=[5, 10, 15, 70])[0]
            total = random.randint(500, 500000)
            f.write(
                f"INSERT INTO sales_orders (order_id, order_number, customer_id, order_date, status, sales_rep_id, warehouse_id, total_amount, discount_percent) VALUES ({i}, 'SO-{i:06d}', {cust}, '{ord_date}', '{status}', {random.randint(1, 100)}, {random.randint(1, 10)}, {total}, {random.choice([0, 0, 0, 5, 10])});\n"
            )

        # Sales order items
        soi_id = 1
        for so in range(1, 30001):
            n_items = random.randint(1, 8)
            for _ in range(n_items):
                prod = random.randint(1, 2000)
                qty = random.randint(1, 20)
                price = random.randint(100, 20000)
                f.write(
                    f"INSERT INTO sales_order_items (soi_id, order_id, product_id, quantity, unit_price) VALUES ({soi_id}, {so}, {prod}, {qty}, {price});\n"
                )
                soi_id += 1

        # Inventory
        for w in range(1, 11):
            for p in range(1, 501):
                qty = random.randint(0, 1000)
                f.write(
                    f"INSERT INTO inventory (product_id, warehouse_id, quantity, min_stock_level) VALUES ({p}, {w}, {qty}, {random.randint(10, 100)});\n"
                )

        # Inventory movements (10000)
        for i in range(1, 10001):
            prod = random.randint(1, 500)
            wh = random.randint(1, 10)
            mtype = random.choice(['receipt', 'shipment', 'transfer_in', 'transfer_out', 'adjustment'])
            qty = random.randint(1, 100)
            mdate = random_date(2020, 2025)
            f.write(
                f"INSERT INTO inventory_movements (movement_id, product_id, warehouse_id, movement_type, quantity, movement_date, employee_id) VALUES ({i}, {prod}, {wh}, '{mtype}', {qty}, '{mdate}', {random.randint(1, 100)});\n"
            )

        # Returns (1500)
        for i in range(1, 1501):
            order_id = random.randint(1, 30000)
            cust = random.randint(1, 2500)
            rdate = random_date(2020, 2025)
            status = random.choice(['received', 'inspected', 'refunded'])
            f.write(
                f"INSERT INTO returns (return_id, return_number, order_id, customer_id, return_date, status, refund_amount) VALUES ({i}, 'RET-{i:06d}', {order_id}, {cust}, '{rdate}', '{status}', {random.randint(500, 50000)});\n"
            )

        # Payments (25000)
        for i in range(1, 25001):
            order_id = random.randint(1, 30000)
            pdate = random_date(2020, 2025)
            amount = random.randint(1000, 200000)
            method = random.choice(['cash', 'card', 'bank_transfer', 'invoice'])
            f.write(
                f"INSERT INTO payments (payment_id, order_id, payment_date, amount, payment_method, status) VALUES ({i}, {order_id}, '{pdate}', {amount}, '{method}', 'completed');\n"
            )

        # Promotions (50)
        for i in range(1, 51):
            start = random_date(2020, 2024)
            end = random_date(2021, 2025)
            if end <= start:
                end = start
            f.write(
                f"INSERT INTO promotions (promotion_id, promotion_name, promotion_type, discount_percent, start_date, end_date, is_active) VALUES ({i}, 'Promotion_{i}', '{random.choice(['discount', 'bundle', 'gift'])}', {random.randint(5, 30)}, '{start}', '{end}', {random.choice([True, False])});\n"
            )

        # Promotion products
        for i in range(1, 51):
            for _ in range(random.randint(3, 15)):
                prod = random.randint(1, 2000)
                f.write(
                    f"INSERT INTO promotion_products (promotion_id, product_id, special_price) VALUES ({i}, {prod}, {random.randint(500, 20000)});\n"
                )


if __name__ == '__main__':
    generate_trading_data()
    print("Data generation complete. Check data.sql")

