"""Data generation for the legal firm. Data for 2020–2025."""
import random
from datetime import datetime, timedelta
from pathlib import Path

OUTPUT = Path(__file__).parent / 'data.sql'
random.seed(42)


def rd(start_year=2020, end_year=2025):
    s = datetime(start_year, 1, 1)
    e = datetime(end_year, 12, 31)
    return (s + timedelta(days=random.randint(0, (e - s).days))).strftime('%Y-%m-%d')


with open(OUTPUT, 'w', encoding='utf-8') as f:
    # Practice areas
    areas = [(i, f'Practice_{i}', f'Description {i}', None) for i in range(1, 16)]
    for a in areas:
        parent = 'NULL' if a[3] is None else str(a[3])
        f.write(
            f"INSERT INTO practice_areas (practice_area_id, area_name, description, parent_area_id) VALUES ({a[0]}, '{a[1]}', '{a[2]}', {parent});\n"
        )

    # Courts
    cities = ['Moscow', 'Saint Petersburg', 'Novosibirsk', 'Yekaterinburg', 'Kazan']
    for i in range(1, 31):
        f.write(
            f"INSERT INTO courts (court_id, court_name, court_type, city) VALUES ({i}, 'Court_{i}', 'Arbitration', '{random.choice(cities)}');\n"
        )

    # Clients (500 corporate + 1500 individual)
    for i in range(1, 501):
        f.write(
            f"INSERT INTO clients (client_id, client_type, company_name, inn, city, registration_date) VALUES ({i}, 'corporate', 'Client_LLC_{i}', '{random.randint(1000000000, 9999999999)}', '{random.choice(cities)}', '{rd(2018, 2023)}');\n"
        )
    for i in range(501, 2001):
        f.write(
            f"INSERT INTO clients (client_id, client_type, first_name, last_name, city, registration_date) VALUES ({i}, 'individual', 'FirstName_{i}', 'LastName_{i}', '{random.choice(cities)}', '{rd(2018, 2023)}');\n"
        )

    # Lawyers
    for i in range(1, 51):
        f.write(
            f"INSERT INTO lawyers (lawyer_id, first_name, last_name, position, practice_area_id, hire_date, hourly_rate, is_partner) VALUES ({i}, 'Lawyer_{i}', 'LastName', 'Attorney', {random.randint(1, 15)}, '{rd(2015, 2022)}', {random.randint(3000, 15000)}, {i <= 10});\n"
        )

    # Cases (3000)
    for i in range(1, 3001):
        status = random.choices(
            ['open', 'in_progress', 'won', 'lost', 'settled', 'closed'],
            weights=[5, 15, 20, 10, 15, 35],
        )[0]
        f.write(
            f"INSERT INTO cases (case_id, case_number, case_title, client_id, practice_area_id, case_type, status, court_id, filing_date, closing_date, estimated_value) VALUES ({i}, 'CASE-{i:05d}', 'Case_{i}', {random.randint(1, 2000)}, {random.randint(1, 15)}, '{random.choice(['civil', 'criminal', 'arbitration', 'corporate'])}', '{status}', {random.randint(1, 30)}, '{rd(2020, 2024)}', {f\"'{rd(2021, 2025)}'\" if status in ['won', 'lost', 'settled', 'closed'] else 'NULL'}, {random.randint(100000, 50000000)});\n"
        )

    # Case assignments
    for c in range(1, 3001):
        for _ in range(random.randint(1, 4)):
            lid = random.randint(1, 50)
            f.write(
                f"INSERT INTO case_assignments (case_id, lawyer_id, role, assigned_date, hours_billed) VALUES ({c}, {lid}, '{random.choice(['lead', 'associate', 'counsel'])}', '{rd(2020, 2024)}', {round(random.uniform(5, 200), 2)});\n"
            )

    # Hearings (5000)
    for i in range(1, 5001):
        cid = random.randint(1, 3000)
        f.write(
            f"INSERT INTO hearings (hearing_id, case_id, court_id, hearing_date, hearing_type, outcome) VALUES ({i}, {cid}, {random.randint(1, 30)}, '{rd(2020, 2025)}', 'Hearing', 'Reviewed');\n"
        )

    # Time entries (20000)
    for i in range(1, 20001):
        cid = random.randint(1, 3000)
        lid = random.randint(1, 50)
        f.write(
            f"INSERT INTO time_entries (time_entry_id, case_id, lawyer_id, entry_date, hours, activity_type, billable, billed) VALUES ({i}, {cid}, {lid}, '{rd(2020, 2025)}', {round(random.uniform(0.5, 8), 2)}, '{random.choice(['research', 'drafting', 'court', 'meeting'])}', true, {random.choice([True, False])});\n"
        )

    # Invoices (5000)
    for i in range(1, 5001):
        cid = random.randint(1, 2000)
        amt = random.randint(50000, 2000000)
        status = random.choices(['draft', 'sent', 'partial', 'paid'], weights=[5, 15, 20, 60])[0]
        paid = amt if status == 'paid' else (amt // 2 if status == 'partial' else 0)
        f.write(
            f"INSERT INTO invoices (invoice_id, invoice_number, client_id, case_id, issue_date, total_amount, paid_amount, status) VALUES ({i}, 'INV-{i:05d}', {cid}, {random.randint(1, 3000)}, '{rd(2020, 2025)}', {amt}, {paid}, '{status}');\n"
        )

    # Documents (8000)
    for i in range(1, 8001):
        f.write(
            f"INSERT INTO documents (document_id, case_id, document_type, document_name, upload_date) VALUES ({i}, {random.randint(1, 3000)}, '{random.choice(['contract', 'pleading', 'evidence', 'court_order'])}', 'Doc_{i}', '{rd(2020, 2025)}');\n"
        )

    # Deadlines (6000)
    for i in range(1, 6001):
        f.write(
            f"INSERT INTO deadlines (deadline_id, case_id, deadline_type, deadline_date, completed, responsible_lawyer_id) VALUES ({i}, {random.randint(1, 3000)}, 'Deadline', '{rd(2020, 2025)}', {random.choice([True, False])}, {random.randint(1, 50)});\n"
        )

    # Case expenses (4000)
    for i in range(1, 4001):
        f.write(
            f"INSERT INTO case_expenses (expense_id, case_id, expense_date, expense_type, amount, reimbursable) VALUES ({i}, {random.randint(1, 3000)}, '{rd(2020, 2025)}', 'Expense', {random.randint(1000, 100000)}, {random.choice([True, False])});\n"
        )

    # Payments (6000)
    for i in range(1, 6001):
        f.write(
            f"INSERT INTO payments (payment_id, client_id, invoice_id, payment_date, amount, payment_method) VALUES ({i}, {random.randint(1, 2000)}, {random.randint(1, 5000)}, '{rd(2020, 2025)}', {random.randint(10000, 500000)}, 'Bank');\n"
        )


print("Legal firm data generated.")

