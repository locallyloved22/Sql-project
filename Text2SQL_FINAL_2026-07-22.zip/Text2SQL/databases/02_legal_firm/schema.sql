-- ============================================
-- БАЗА ДАННЫХ: ЮРИДИЧЕСКАЯ ФИРМА
-- ============================================

-- Справочники
CREATE TABLE practice_areas (
    practice_area_id SERIAL PRIMARY KEY,
    area_name VARCHAR(100) NOT NULL,
    description TEXT,
    parent_area_id INT REFERENCES practice_areas(practice_area_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE courts (
    court_id SERIAL PRIMARY KEY,
    court_name VARCHAR(200) NOT NULL,
    court_type VARCHAR(50),
    jurisdiction VARCHAR(100),
    address TEXT,
    city VARCHAR(100),
    region VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE clients (
    client_id SERIAL PRIMARY KEY,
    client_type VARCHAR(20) CHECK (client_type IN ('individual', 'corporate')),
    company_name VARCHAR(200),
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    inn VARCHAR(20),
    ogrn VARCHAR(20),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    city VARCHAR(100),
    registration_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE lawyers (
    lawyer_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    position VARCHAR(100),
    practice_area_id INT REFERENCES practice_areas(practice_area_id),
    hire_date DATE,
    license_number VARCHAR(50),
    hourly_rate DECIMAL(10,2),
    is_partner BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE support_staff (
    staff_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    position VARCHAR(100),
    department VARCHAR(100),
    hire_date DATE,
    salary DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Дела и судебные процессы
CREATE TABLE cases (
    case_id SERIAL PRIMARY KEY,
    case_number VARCHAR(50) UNIQUE NOT NULL,
    case_title VARCHAR(300) NOT NULL,
    client_id INT NOT NULL REFERENCES clients(client_id),
    practice_area_id INT NOT NULL REFERENCES practice_areas(practice_area_id),
    case_type VARCHAR(50) CHECK (case_type IN ('civil', 'criminal', 'arbitration', 'administrative', 'corporate', 'ip', 'tax')),
    status VARCHAR(30) CHECK (status IN ('open', 'in_progress', 'pending', 'won', 'lost', 'settled', 'closed')),
    court_id INT REFERENCES courts(court_id),
    filing_date DATE,
    closing_date DATE,
    estimated_value DECIMAL(14,2),
    outcome VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE case_assignments (
    assignment_id SERIAL PRIMARY KEY,
    case_id INT NOT NULL REFERENCES cases(case_id),
    lawyer_id INT NOT NULL REFERENCES lawyers(lawyer_id),
    role VARCHAR(50) CHECK (role IN ('lead', 'associate', 'counsel', 'paralegal')),
    assigned_date DATE,
    hours_billed DECIMAL(8,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE hearings (
    hearing_id SERIAL PRIMARY KEY,
    case_id INT NOT NULL REFERENCES cases(case_id),
    court_id INT NOT NULL REFERENCES courts(court_id),
    hearing_date DATE NOT NULL,
    hearing_time TIME,
    hearing_type VARCHAR(50),
    room_number VARCHAR(20),
    outcome VARCHAR(200),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE documents (
    document_id SERIAL PRIMARY KEY,
    case_id INT REFERENCES cases(case_id),
    document_type VARCHAR(50) CHECK (document_type IN ('contract', 'pleading', 'evidence', 'correspondence', 'court_order', 'agreement', 'power_of_attorney')),
    document_name VARCHAR(200) NOT NULL,
    file_path VARCHAR(500),
    upload_date DATE,
    uploaded_by INT REFERENCES lawyers(lawyer_id),
    version INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Время и биллинг
CREATE TABLE time_entries (
    time_entry_id SERIAL PRIMARY KEY,
    case_id INT NOT NULL REFERENCES cases(case_id),
    lawyer_id INT NOT NULL REFERENCES lawyers(lawyer_id),
    entry_date DATE NOT NULL,
    hours DECIMAL(6,2) NOT NULL,
    description TEXT,
    activity_type VARCHAR(50) CHECK (activity_type IN ('research', 'drafting', 'court', 'meeting', 'correspondence', 'review', 'other')),
    billable BOOLEAN DEFAULT TRUE,
    billed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoices (
    invoice_id SERIAL PRIMARY KEY,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    client_id INT NOT NULL REFERENCES clients(client_id),
    case_id INT REFERENCES cases(case_id),
    issue_date DATE NOT NULL,
    due_date DATE,
    total_amount DECIMAL(12,2) NOT NULL,
    paid_amount DECIMAL(12,2) DEFAULT 0,
    status VARCHAR(20) CHECK (status IN ('draft', 'sent', 'partial', 'paid', 'overdue')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoice_items (
    item_id SERIAL PRIMARY KEY,
    invoice_id INT NOT NULL REFERENCES invoices(invoice_id),
    description TEXT,
    quantity DECIMAL(8,2),
    unit_price DECIMAL(10,2),
    amount DECIMAL(12,2),
    time_entry_id INT REFERENCES time_entries(time_entry_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Контрагенты и оппоненты
CREATE TABLE opposing_parties (
    party_id SERIAL PRIMARY KEY,
    case_id INT NOT NULL REFERENCES cases(case_id),
    party_name VARCHAR(200) NOT NULL,
    party_type VARCHAR(30),
    lawyer_name VARCHAR(100),
    contact_info TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE contracts (
    contract_id SERIAL PRIMARY KEY,
    client_id INT NOT NULL REFERENCES clients(client_id),
    contract_type VARCHAR(50),
    contract_number VARCHAR(50),
    signing_date DATE,
    expiry_date DATE,
    value DECIMAL(14,2),
    status VARCHAR(20) CHECK (status IN ('draft', 'active', 'expired', 'terminated')),
    responsible_lawyer_id INT REFERENCES lawyers(lawyer_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Календарь и дедлайны
CREATE TABLE deadlines (
    deadline_id SERIAL PRIMARY KEY,
    case_id INT NOT NULL REFERENCES cases(case_id),
    deadline_type VARCHAR(50),
    deadline_date DATE NOT NULL,
    description TEXT,
    completed BOOLEAN DEFAULT FALSE,
    completed_date DATE,
    responsible_lawyer_id INT REFERENCES lawyers(lawyer_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Расходы по делам
CREATE TABLE case_expenses (
    expense_id SERIAL PRIMARY KEY,
    case_id INT NOT NULL REFERENCES cases(case_id),
    expense_date DATE NOT NULL,
    expense_type VARCHAR(50),
    amount DECIMAL(12,2) NOT NULL,
    description TEXT,
    reimbursable BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Платежи клиентов
CREATE TABLE payments (
    payment_id SERIAL PRIMARY KEY,
    client_id INT NOT NULL REFERENCES clients(client_id),
    invoice_id INT REFERENCES invoices(invoice_id),
    payment_date DATE NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    payment_method VARCHAR(30),
    reference_number VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Офисы фирмы
CREATE TABLE offices (
    office_id SERIAL PRIMARY KEY,
    office_name VARCHAR(100) NOT NULL,
    address TEXT,
    city VARCHAR(100),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Заметки по делам
CREATE TABLE case_notes (
    note_id SERIAL PRIMARY KEY,
    case_id INT NOT NULL REFERENCES cases(case_id),
    lawyer_id INT REFERENCES lawyers(lawyer_id),
    note_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    note_text TEXT NOT NULL,
    is_confidential BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Конфликты интересов
CREATE TABLE conflict_checks (
    check_id SERIAL PRIMARY KEY,
    client_id INT NOT NULL REFERENCES clients(client_id),
    case_id INT REFERENCES cases(case_id),
    check_date DATE NOT NULL,
    result VARCHAR(20) CHECK (result IN ('clear', 'conflict', 'waived')),
    notes TEXT,
    checked_by INT REFERENCES lawyers(lawyer_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
