"""Генерация данных для логистической компании. 2020-2025."""
import random
from datetime import datetime, timedelta
from pathlib import Path

OUTPUT = Path(__file__).parent / 'data.sql'
random.seed(43)

def rd(sy=2020, ey=2025):
    s, e = datetime(sy,1,1), datetime(ey,12,31)
    return (s + timedelta(days=random.randint(0,(e-s).days))).strftime('%Y-%m-%d')

with open(OUTPUT, 'w', encoding='utf-8') as f:
    # Locations (50)
    for i in range(1, 51):
        f.write(f"INSERT INTO locations (location_id, location_code, location_name, location_type, city, country) VALUES ({i}, 'LOC-{i:03d}', 'Точка_{i}', '{random.choice(['warehouse','hub','terminal','customer'])}', 'Город_{i%20}', 'Россия');\n")
    
    # Vehicle types
    for i in range(1, 11):
        f.write(f"INSERT INTO vehicle_types (vehicle_type_id, type_name, capacity_kg, fuel_type) VALUES ({i}, 'Тип_{i}', {random.randint(1000,20000)}, 'Дизель');\n")
    
    # Vehicles (200)
    for i in range(1, 201):
        f.write(f"INSERT INTO vehicles (vehicle_id, vehicle_number, vehicle_type_id, current_location_id, status, mileage_km) VALUES ({i}, 'V-{i:04d}', {random.randint(1,10)}, {random.randint(1,50)}, '{random.choice(['available','in_transit','maintenance'])}', {random.randint(10000,500000)});\n")
    
    # Drivers (150)
    for i in range(1, 151):
        f.write(f"INSERT INTO drivers (driver_id, first_name, last_name, hire_date, status, current_vehicle_id) VALUES ({i}, 'Водитель_{i}', 'Фамилия', '{rd(2018,2023)}', '{random.choice(['available','on_route','off_duty'])}', {random.randint(1,200) if random.random()>0.3 else 'NULL'});\n")
    
    # Customers (300)
    for i in range(1, 301):
        f.write(f"INSERT INTO customers (customer_id, customer_name, customer_type, city, contract_start_date) VALUES ({i}, 'Клиент_{i}', '{random.choice(['shipper','consignee','both'])}', 'Город_{i%30}', '{rd(2019,2023)}');\n")
    
    # Cargo types
    for i in range(1, 16):
        f.write(f"INSERT INTO cargo_types (cargo_type_id, type_name, hazard_class) VALUES ({i}, 'Груз_{i}', 'Класс_{random.randint(1,9)}');\n")
    
    # Shipments (25000)
    for i in range(1, 25001):
        status = random.choices(['booked','picked_up','in_transit','delivered','cancelled'], weights=[5,10,15,65,5])[0]
        f.write(f"INSERT INTO shipments (shipment_id, tracking_number, shipper_id, consignee_id, origin_location_id, destination_location_id, shipment_date, status, total_weight_kg, total_volume_cbm, declared_value) VALUES ({i}, 'TRK-{i:07d}', {random.randint(1,300)}, {random.randint(1,300)}, {random.randint(1,50)}, {random.randint(1,50)}, '{rd(2020,2025)}', '{status}', {round(random.uniform(1,500), 2)}, {round(random.uniform(0.1,20), 2)}, {random.randint(1000,500000)});\n")
    
    # Shipment items
    for s in range(1, 25001):
        for _ in range(random.randint(1, 5)):
            f.write(f"INSERT INTO shipment_items (shipment_id, cargo_type_id, description, quantity, weight_kg, volume_cbm) VALUES ({s}, {random.randint(1,15)}, 'Груз', {random.randint(1,50)}, {round(random.uniform(1,100), 2)}, {round(random.uniform(0.01,5), 2)});\n")
    
    # Routes (100)
    for i in range(1, 101):
        o, d = random.randint(1,50), random.randint(1,50)
        if o==d: d = (d % 50) + 1
        f.write(f"INSERT INTO routes (route_id, route_code, origin_location_id, destination_location_id, distance_km, estimated_duration_hours, route_type) VALUES ({i}, 'R-{i:03d}', {o}, {d}, {random.randint(100,3000)}, {random.randint(5,72)}, '{random.choice(['regular','express'])}');\n")
    
    # Trips (15000)
    for i in range(1, 15001):
        f.write(f"INSERT INTO trips (trip_id, trip_number, route_id, vehicle_id, driver_id, planned_departure, status, fuel_consumed_liters) VALUES ({i}, 'TRIP-{i:05d}', {random.randint(1,100)}, {random.randint(1,200)}, {random.randint(1,150)}, '{rd(2020,2025)} {random.randint(8,20):02d}:00:00', '{random.choice(['scheduled','in_progress','completed'])}', {round(random.uniform(50,500), 2)});\n")
    
    # Tracking events (40000)
    for i in range(1, 40001):
        sid = random.randint(1, 25000)
        f.write(f"INSERT INTO tracking_events (event_id, shipment_id, location_id, event_type, event_timestamp) VALUES ({i}, {sid}, {random.randint(1,50)}, '{random.choice(['picked_up','departed','arrived','in_transit','delivered'])}', '{rd(2020,2025)} {random.randint(0,23):02d}:{random.randint(0,59):02d}:00');\n")
    
    # Invoices (8000)
    for i in range(1, 8001):
        f.write(f"INSERT INTO invoices (invoice_id, invoice_number, customer_id, invoice_date, total_amount, status) VALUES ({i}, 'INV-{i:05d}', {random.randint(1,300)}, '{rd(2020,2025)}', {random.randint(5000,200000)}, '{random.choice(['sent','paid','overdue'])}');\n")
    
    # Incidents (1500)
    for i in range(1, 1501):
        f.write(f"INSERT INTO incidents (incident_id, shipment_id, incident_type, incident_date, description, cost) VALUES ({i}, {random.randint(1,25000)}, '{random.choice(['delay','damage','loss'])}', '{rd(2020,2025)}', 'Инцидент', {random.randint(1000,50000)});\n")
    
    # Fuel transactions (5000)
    for i in range(1, 5001):
        f.write(f"INSERT INTO fuel_transactions (transaction_id, vehicle_id, transaction_date, liters, cost, odometer_reading) VALUES ({i}, {random.randint(1,200)}, '{rd(2020,2025)}', {round(random.uniform(50,300), 2)}, {random.randint(5000,30000)}, {random.randint(50000,500000)});\n")

print("Logistics data generated.")
