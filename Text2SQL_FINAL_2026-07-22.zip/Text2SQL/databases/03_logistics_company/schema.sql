-- ============================================
-- БАЗА ДАННЫХ: ЛОГИСТИЧЕСКАЯ КОМПАНИЯ
-- ============================================

-- Справочники
CREATE TABLE locations (
    location_id SERIAL PRIMARY KEY,
    location_code VARCHAR(20) UNIQUE NOT NULL,
    location_name VARCHAR(100) NOT NULL,
    location_type VARCHAR(30) CHECK (location_type IN ('warehouse', 'hub', 'terminal', 'customer', 'port', 'airport')),
    address TEXT,
    city VARCHAR(100),
    region VARCHAR(100),
    country VARCHAR(50),
    latitude DECIMAL(10,6),
    longitude DECIMAL(10,6),
    timezone VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE vehicle_types (
    vehicle_type_id SERIAL PRIMARY KEY,
    type_name VARCHAR(50) NOT NULL,
    capacity_kg DECIMAL(12,2),
    capacity_volume_cbm DECIMAL(10,2),
    fuel_type VARCHAR(30),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE vehicles (
    vehicle_id SERIAL PRIMARY KEY,
    vehicle_number VARCHAR(20) UNIQUE NOT NULL,
    vehicle_type_id INT NOT NULL REFERENCES vehicle_types(vehicle_type_id),
    current_location_id INT REFERENCES locations(location_id),
    status VARCHAR(20) CHECK (status IN ('available', 'in_transit', 'maintenance', 'out_of_service')),
    purchase_date DATE,
    last_maintenance_date DATE,
    mileage_km INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE drivers (
    driver_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    license_number VARCHAR(50),
    license_expiry DATE,
    hire_date DATE,
    phone VARCHAR(20),
    email VARCHAR(100),
    current_vehicle_id INT REFERENCES vehicles(vehicle_id),
    status VARCHAR(20) CHECK (status IN ('available', 'on_route', 'off_duty', 'sick_leave')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    customer_name VARCHAR(200) NOT NULL,
    customer_type VARCHAR(30) CHECK (customer_type IN ('shipper', 'consignee', 'both')),
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(50),
    tax_id VARCHAR(50),
    contract_start_date DATE,
    contract_end_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cargo_types (
    cargo_type_id SERIAL PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL,
    hazard_class VARCHAR(20),
    requires_temperature BOOLEAN DEFAULT FALSE,
    min_temp DECIMAL(5,2),
    max_temp DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Заказы и перевозки
CREATE TABLE shipments (
    shipment_id SERIAL PRIMARY KEY,
    tracking_number VARCHAR(50) UNIQUE NOT NULL,
    shipper_id INT NOT NULL REFERENCES customers(customer_id),
    consignee_id INT NOT NULL REFERENCES customers(customer_id),
    origin_location_id INT NOT NULL REFERENCES locations(location_id),
    destination_location_id INT NOT NULL REFERENCES locations(location_id),
    shipment_date DATE,
    expected_delivery_date DATE,
    actual_delivery_date DATE,
    status VARCHAR(30) CHECK (status IN ('booked', 'picked_up', 'in_transit', 'at_hub', 'out_for_delivery', 'delivered', 'cancelled')),
    total_weight_kg DECIMAL(12,3),
    total_volume_cbm DECIMAL(10,3),
    declared_value DECIMAL(14,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE shipment_items (
    item_id SERIAL PRIMARY KEY,
    shipment_id INT NOT NULL REFERENCES shipments(shipment_id),
    cargo_type_id INT REFERENCES cargo_types(cargo_type_id),
    description VARCHAR(200),
    quantity INT,
    weight_kg DECIMAL(10,3),
    volume_cbm DECIMAL(8,3),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Маршруты
CREATE TABLE routes (
    route_id SERIAL PRIMARY KEY,
    route_code VARCHAR(20) UNIQUE NOT NULL,
    origin_location_id INT NOT NULL REFERENCES locations(location_id),
    destination_location_id INT NOT NULL REFERENCES locations(location_id),
    distance_km DECIMAL(10,2),
    estimated_duration_hours DECIMAL(6,2),
    route_type VARCHAR(30) CHECK (route_type IN ('regular', 'express', 'charter')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE route_legs (
    leg_id SERIAL PRIMARY KEY,
    route_id INT NOT NULL REFERENCES routes(route_id),
    leg_sequence INT NOT NULL,
    from_location_id INT NOT NULL REFERENCES locations(location_id),
    to_location_id INT NOT NULL REFERENCES locations(location_id),
    distance_km DECIMAL(10,2),
    transport_mode VARCHAR(30) CHECK (transport_mode IN ('road', 'rail', 'sea', 'air', 'multimodal')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Рейсы
CREATE TABLE trips (
    trip_id SERIAL PRIMARY KEY,
    trip_number VARCHAR(50) UNIQUE NOT NULL,
    route_id INT REFERENCES routes(route_id),
    vehicle_id INT REFERENCES vehicles(vehicle_id),
    driver_id INT REFERENCES drivers(driver_id),
    planned_departure TIMESTAMP,
    actual_departure TIMESTAMP,
    planned_arrival TIMESTAMP,
    actual_arrival TIMESTAMP,
    status VARCHAR(30) CHECK (status IN ('scheduled', 'in_progress', 'completed', 'cancelled', 'delayed')),
    fuel_consumed_liters DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE trip_shipments (
    ts_id SERIAL PRIMARY KEY,
    trip_id INT NOT NULL REFERENCES trips(trip_id),
    shipment_id INT NOT NULL REFERENCES shipments(shipment_id),
    loaded_at_location_id INT REFERENCES locations(location_id),
    unloaded_at_location_id INT REFERENCES locations(location_id),
    loaded_at TIMESTAMP,
    unloaded_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Отслеживание
CREATE TABLE tracking_events (
    event_id SERIAL PRIMARY KEY,
    shipment_id INT NOT NULL REFERENCES shipments(shipment_id),
    location_id INT REFERENCES locations(location_id),
    event_type VARCHAR(50) CHECK (event_type IN ('picked_up', 'departed', 'arrived', 'in_transit', 'delivered', 'exception', 'delay')),
    event_timestamp TIMESTAMP NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Тарифы и расценки
CREATE TABLE pricing_zones (
    zone_id SERIAL PRIMARY KEY,
    zone_name VARCHAR(50) NOT NULL,
    origin_region VARCHAR(100),
    destination_region VARCHAR(100),
    rate_per_kg DECIMAL(10,2),
    rate_per_cbm DECIMAL(10,2),
    min_charge DECIMAL(10,2),
    valid_from DATE,
    valid_to DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoices (
    invoice_id SERIAL PRIMARY KEY,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT NOT NULL REFERENCES customers(customer_id),
    invoice_date DATE NOT NULL,
    due_date DATE,
    total_amount DECIMAL(14,2),
    status VARCHAR(20) CHECK (status IN ('draft', 'sent', 'paid', 'overdue')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoice_lines (
    line_id SERIAL PRIMARY KEY,
    invoice_id INT NOT NULL REFERENCES invoices(invoice_id),
    shipment_id INT REFERENCES shipments(shipment_id),
    description TEXT,
    quantity DECIMAL(10,2),
    unit_price DECIMAL(10,2),
    amount DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Складские операции
CREATE TABLE warehouse_operations (
    operation_id SERIAL PRIMARY KEY,
    location_id INT NOT NULL REFERENCES locations(location_id),
    operation_type VARCHAR(30) CHECK (operation_type IN ('receipt', 'dispatch', 'transfer', 'inventory')),
    shipment_id INT REFERENCES shipments(shipment_id),
    operation_date TIMESTAMP NOT NULL,
    performed_by VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Задержки и инциденты
CREATE TABLE incidents (
    incident_id SERIAL PRIMARY KEY,
    shipment_id INT REFERENCES shipments(shipment_id),
    trip_id INT REFERENCES trips(trip_id),
    incident_type VARCHAR(50) CHECK (incident_type IN ('delay', 'damage', 'loss', 'accident', 'customs', 'other')),
    incident_date TIMESTAMP NOT NULL,
    description TEXT,
    resolution TEXT,
    cost DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Тарифы для клиентов
CREATE TABLE customer_contracts (
    contract_id SERIAL PRIMARY KEY,
    customer_id INT NOT NULL REFERENCES customers(customer_id),
    contract_number VARCHAR(50),
    start_date DATE,
    end_date DATE,
    discount_percent DECIMAL(5,2),
    payment_terms_days INT,
    status VARCHAR(20) CHECK (status IN ('active', 'expired', 'cancelled')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Топливо
CREATE TABLE fuel_transactions (
    transaction_id SERIAL PRIMARY KEY,
    vehicle_id INT REFERENCES vehicles(vehicle_id),
    transaction_date DATE NOT NULL,
    liters DECIMAL(10,2) NOT NULL,
    cost DECIMAL(12,2),
    location_id INT REFERENCES locations(location_id),
    odometer_reading INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
