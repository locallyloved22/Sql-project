from __future__ import annotations

import os
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any


def load_dotenv(path: str | Path | None = None) -> None:
    """Минимальный dotenv loader без перезаписи уже экспортированных переменных."""
    env_path = Path(path) if path else Path(__file__).resolve().parents[1] / ".env"
    if not env_path.exists():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key.strip(), value)


@dataclass
class Config:
    provider: str = "openai"
    model: str = ""
    base_url: str = "https://api.openai.com/v1"
    temperature: float = 0.0
    timeout_seconds: float = 30.0
    statement_timeout_ms: int = 5000
    schema_linking: bool = True
    max_tables: int = 8
    few_shot_mode: str = "retrieval"
    few_shot_count: int = 4
    validation: bool = True
    self_correction: bool = True
    max_corrections: int = 2

    @property
    def api_key(self) -> str | None:
        return os.getenv("LLM_API_KEY") or None

    @classmethod
    def from_file(cls, path: str | Path | None = None, **overrides: Any) -> "Config":
        load_dotenv()
        raw: dict[str, Any] = {}
        if path:
            try:
                import yaml
            except ImportError as exc:
                raise RuntimeError("Для YAML-конфига установите PyYAML: pip install PyYAML") from exc
            raw = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
        env = {
            "provider": os.getenv("LLM_PROVIDER"),
            "model": os.getenv("LLM_MODEL"),
            "base_url": os.getenv("LLM_BASE_URL"),
        }
        raw.update({k: v for k, v in env.items() if v})
        raw.update({k: v for k, v in overrides.items() if v is not None})
        allowed = {f.name for f in fields(cls)}
        unknown = set(raw) - allowed
        if unknown:
            raise ValueError(f"Неизвестные параметры конфигурации: {sorted(unknown)}")
        config = cls(**raw)
        if config.provider not in {"mock", "openai", "ollama"}:
            raise ValueError("provider должен быть mock, openai или ollama")
        if config.few_shot_mode not in {"zero", "static", "retrieval"}:
            raise ValueError("few_shot_mode должен быть zero, static или retrieval")
        return config
